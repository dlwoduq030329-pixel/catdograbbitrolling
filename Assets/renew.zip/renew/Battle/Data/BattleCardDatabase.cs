using System.Collections.Generic;
using UnityEngine;

/// <summary>카드의 전투 역할 분류.</summary>
public enum BattleCardCategory
{
    [InspectorName("공격")]
    Attack,
    [InspectorName("방어")]
    Defense,
    [InspectorName("지원")]
    Support,
    [InspectorName("이동")]
    Movement,
    [InspectorName("기타/유틸리티")]
    Utility
}

/// <summary>카드를 사용할 수 있는 대상 종류.</summary>
public enum BattleCardTargetType
{
    [InspectorName("대상 없음")]
    None,
    [InspectorName("자기 자신")]
    Self,
    [InspectorName("적")]
    Enemy,
    [InspectorName("아군")]
    Ally,
    [InspectorName("모든 캐릭터")]
    Character,
    [InspectorName("타일")]
    Tile
}

/// <summary>카드 효과가 적용되는 타일 범위 형태.</summary>
public enum BattleCardAreaType
{
    [InspectorName("단일 대상")]
    Single,
    [InspectorName("십자 범위")]
    Cross,
    [InspectorName("원형 범위")]
    Radius,
    [InspectorName("직선 범위")]
    Line
}

/// <summary>
/// 카드 한 종류의 전투용 정적 데이터다.
/// 패, 덱, 버림 더미와 같은 런타임 상태는 저장하지 않는다.
/// </summary>
[System.Serializable]
public class BattleCardData
{
    [Header("식별 및 표시 정보")]
    [InspectorName("고유 식별자")]
    public string id;
    [InspectorName("표시 이름")]
    public string displayName;
    [InspectorName("카드 이미지")]
    public Sprite artwork;
    [InspectorName("카드 설명")]
    [TextArea(2, 5)] public string description;
    [InspectorName("카드 분류")]
    public BattleCardCategory category = BattleCardCategory.Attack;

    [Header("원본 카드 데이터 연결")]
    [Tooltip("원본 카드 데이터베이스 인덱스입니다. 연결하지 않을 경우 -1을 사용합니다.")]
    [InspectorName("기존 카드 인덱스")]
    [Min(-1)] public int legacyCardIndex = -1;

    [Header("사용 비용")]
    [InspectorName("행동력 비용")]
    [Range(0, 10)] public int mpCost = 1;

    [Header("대상 및 사거리")]
    [InspectorName("대상 종류")]
    public BattleCardTargetType targetType = BattleCardTargetType.Enemy;
    [InspectorName("사용 사거리(칸)")]
    [Min(0)] public int rangeTiles = 1;
    [InspectorName("범위 형태")]
    public BattleCardAreaType areaType = BattleCardAreaType.Single;
    [Tooltip("단일 대상은 0, 십자/원형/직선 범위는 효과가 퍼지는 칸 수를 사용합니다.")]
    [InspectorName("효과 범위 크기(칸)")]
    [Min(0)] public int areaSizeTiles;

    [Header("기본 효과 수치")]
    [InspectorName("피해량")]
    [Min(0f)] public float damage;
    [InspectorName("회복량")]
    [Min(0f)] public float healing;
    [InspectorName("보호막량")]
    [Min(0f)] public float shield;
}

/// <summary>renew 전투에서 사용하는 카드 정적 데이터 목록 에셋.</summary>
[CreateAssetMenu(fileName = "BattleCardDatabase", menuName = "Renew/전투/카드 데이터베이스")]
public class BattleCardDatabase : ScriptableObject
{
    [InspectorName("카드 데이터 목록")]
    [SerializeField] private List<BattleCardData> cards = new List<BattleCardData>();

    public int Count => cards.Count;
    public IReadOnlyList<BattleCardData> Cards => cards;

    /// <summary>유효한 목록 인덱스의 카드를 반환하고, 범위를 벗어나면 null을 반환한다.</summary>
    public BattleCardData GetAt(int index)
    {
        return index >= 0 && index < cards.Count ? cards[index] : null;
    }

    /// <summary>고유 ID가 일치하는 첫 번째 카드를 반환한다.</summary>
    public BattleCardData FindById(string id)
    {
        return cards.Find(card => card != null && card.id == id);
    }

    /// <summary>원본 카드 인덱스가 일치하는 첫 번째 전투 카드를 반환한다.</summary>
    public BattleCardData FindByLegacyCardIndex(int legacyCardIndex)
    {
        return cards.Find(card => card != null && card.legacyCardIndex == legacyCardIndex);
    }
}
