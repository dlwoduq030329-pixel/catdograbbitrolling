using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 선택한 손패 카드가 행동 확정 전까지 유지되도록 묶어 둔 요청이다.
/// 확인 시에만 카드가 버림 더미로 이동하며 취소 시에는 아무 변화가 없다.
/// </summary>
public sealed class PendingBattleCardUse
{
    public int CardIndex { get; }
    public BattleCardData CardData { get; }
    public BattleActionRequest ActionRequest { get; }

    internal PendingBattleCardUse(
        int cardIndex,
        BattleCardData cardData,
        BattleActionRequest actionRequest)
    {
        CardIndex = cardIndex;
        CardData = cardData;
        ActionRequest = actionRequest;
    }
}

/// <summary>
/// 플레이어 전투 덱, 손패, 버림 더미와 턴 시작 드로우를 관리한다.
/// 카드 UI는 HandChanged 이벤트와 BeginCardUse/ConfirmCardUse API만 사용한다.
/// </summary>
public class BattleCardDrawSystem : MonoBehaviour
{
    [Header("전투 카드 데이터")]
    [InspectorName("전투 카드 데이터베이스")]
    [SerializeField] private BattleCardDatabase battleCardDatabase;

    [Header("드로우 규칙")]
    [InspectorName("최대 손패 수")]
    [SerializeField, Min(1)] private int handLimit = 5;
    [InspectorName("전투 시작 시 덱 섞기")]
    [SerializeField] private bool shuffleAtBattleStart = true;

    private readonly List<int> drawPile = new List<int>();
    private readonly List<int> hand = new List<int>();
    private readonly List<int> discardPile = new List<int>();
    private bool initialized;

    public IReadOnlyList<int> DrawPile => drawPile;
    public IReadOnlyList<int> Hand => hand;
    public IReadOnlyList<int> DiscardPile => discardPile;
    public int HandLimit => handLimit;
    public BattleCardDatabase Database => battleCardDatabase;

    /// <summary>손패가 드로우되거나 카드 사용 확정으로 변경될 때 UI에 알린다.</summary>
    public event Action<IReadOnlyList<int>> HandChanged;
    public event Action<int> CardDrawn;

    /// <summary>BattleGameManager가 전투에서 사용할 카드 DB를 한 번 전달한다.</summary>
    public void ConfigureDatabase(BattleCardDatabase database)
    {
        battleCardDatabase = database;
    }

    /// <summary>컴포넌트 활성화 시 플레이어 턴 시작 이벤트 구독을 시도한다.</summary>
    private void OnEnable()
    {
        TrySubscribeTurnManager();
    }

    /// <summary>게임 관리자 초기화 순서가 늦은 경우를 대비해 시작 시 구독을 다시 확인한다.</summary>
    private void Start()
    {
        // BattleGameManager보다 먼저 활성화된 경우를 보완한다.
        TrySubscribeTurnManager();
    }

    /// <summary>비활성화 시 턴 이벤트 구독을 해제해 드로우가 중복 실행되지 않게 한다.</summary>
    private void OnDisable()
    {
        if (BattleGameManager.Instance != null)
        {
            BattleGameManager.Instance.PlayerTurnStarted -= HandlePlayerTurnStarted;
        }
    }

    /// <summary>전투 카드 데이터베이스 목록으로 드로우 덱, 손패, 버림 더미를 초기화한다.</summary>
    public void InitializeDeck()
    {
        drawPile.Clear();
        hand.Clear();
        discardPile.Clear();

        if (battleCardDatabase != null)
        {
            for (int cardIndex = 0; cardIndex < battleCardDatabase.Count; cardIndex++)
            {
                if (battleCardDatabase.GetAt(cardIndex) != null)
                {
                    drawPile.Add(cardIndex);
                }
            }
        }

        if (shuffleAtBattleStart)
        {
            Shuffle(drawPile);
        }

        initialized = true;
        DrawToHandLimit();
    }

    /// <summary>현재 손패가 최대 손패 수가 될 때까지 드로우한다.</summary>
    public void DrawToHandLimit()
    {
        while (hand.Count < handLimit && TryDrawOne(out _))
        {
        }

        HandChanged?.Invoke(hand);
    }

    /// <summary>손패 위치의 카드를 전투 행동 요청으로 변환한다. 이 단계에서는 카드를 제거하지 않는다.</summary>
    public bool BeginCardUse(int handIndex, out PendingBattleCardUse pendingUse)
    {
        pendingUse = null;
        if (handIndex < 0 || handIndex >= hand.Count)
        {
            return false;
        }

        int cardIndex = hand[handIndex];
        BattleCardData cardData = battleCardDatabase != null
            ? battleCardDatabase.GetAt(cardIndex)
            : null;

        if (!BattleCardConnector.TryCreateActionRequest(cardData, out BattleActionRequest actionRequest))
        {
            Debug.LogError($"카드 행동 요청 생성 실패: 전투 카드 인덱스 {cardIndex}", this);
            return false;
        }

        pendingUse = new PendingBattleCardUse(cardIndex, cardData, actionRequest);
        return true;
    }

    /// <summary>카드 행동 확정 후 해당 카드 한 장을 손패에서 제거하고 버림 더미로 보낸다.</summary>
    public bool ConfirmCardUse(PendingBattleCardUse pendingUse)
    {
        if (pendingUse == null)
        {
            return false;
        }

        int handIndex = hand.IndexOf(pendingUse.CardIndex);
        if (handIndex < 0)
        {
            return false;
        }

        hand.RemoveAt(handIndex);
        discardPile.Add(pendingUse.CardIndex);
        HandChanged?.Invoke(hand);
        return true;
    }

    /// <summary>카드 한 장을 드로우한다. 덱이 비면 버림 더미를 섞어 새 덱으로 만든다.</summary>
    private bool TryDrawOne(out int cardIndex)
    {
        cardIndex = -1;
        if (drawPile.Count == 0)
        {
            RecycleDiscardPile();
        }

        if (drawPile.Count == 0)
        {
            return false;
        }

        int lastIndex = drawPile.Count - 1;
        cardIndex = drawPile[lastIndex];
        drawPile.RemoveAt(lastIndex);
        hand.Add(cardIndex);
        CardDrawn?.Invoke(cardIndex);
        return true;
    }

    /// <summary>드로우 덱이 비었을 때 버림 더미를 옮겨 섞고 새로운 드로우 덱으로 만든다.</summary>
    private void RecycleDiscardPile()
    {
        if (discardPile.Count == 0)
        {
            return;
        }

        drawPile.AddRange(discardPile);
        discardPile.Clear();
        Shuffle(drawPile);
    }

    /// <summary>첫 턴에는 덱을 초기화하고 이후 턴에는 남은 손패를 버린 뒤 새 손패를 뽑는다.</summary>
    private void HandlePlayerTurnStarted()
    {
        if (!initialized)
        {
            InitializeDeck();
            return;
        }

        DiscardRemainingHand();
        DrawToHandLimit();
    }

    /// <summary>턴 종료 후 남아 있던 손패를 버림 더미로 이동한다.</summary>
    private void DiscardRemainingHand()
    {
        if (hand.Count == 0)
        {
            return;
        }

        discardPile.AddRange(hand);
        hand.Clear();
    }

    /// <summary>전투 게임 관리자가 준비되어 있으면 턴 시작 이벤트를 중복 없이 연결한다.</summary>
    private void TrySubscribeTurnManager()
    {
        if (BattleGameManager.Instance == null)
        {
            return;
        }

        BattleGameManager.Instance.PlayerTurnStarted -= HandlePlayerTurnStarted;
        BattleGameManager.Instance.PlayerTurnStarted += HandlePlayerTurnStarted;
    }

    /// <summary>피셔-예이츠 방식으로 전달된 카드 인덱스 목록을 제자리에서 무작위로 섞는다.</summary>
    private static void Shuffle(List<int> cards)
    {
        for (int i = cards.Count - 1; i > 0; i--)
        {
            int swapIndex = UnityEngine.Random.Range(0, i + 1);
            (cards[i], cards[swapIndex]) = (cards[swapIndex], cards[i]);
        }
    }
}
