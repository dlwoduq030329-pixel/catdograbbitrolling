using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

using Randoom = UnityEngine.Random;

/// <summary>
/// Player/Enemy 턴 전환, 주사위 상태, 생성된 Player 배포를 담당하는 전투 진입점이다.
/// 이동 판단이나 AI 판단은 직접 수행하지 않고 각 전용 컴포넌트에 위임한다.
/// </summary>
public class BattleGameManager : MonoBehaviour
{
    public static BattleGameManager Instance { get; private set; }

    [Header("턴 화면 참조")]
    [InspectorName("턴 종료 버튼")]
    [SerializeField] private Button turnEndButton;
    [InspectorName("주사위 버튼")]
    [SerializeField] private Button diceButton;
    [InspectorName("턴 디버그 텍스트")]
    [SerializeField] private TMP_Text turnDebugText;
    [InspectorName("주사위 디버그 텍스트")]
    [SerializeField] private TMP_Text diceDebugText;

    [Header("플레이어 런타임 참조")]
    [InspectorName("플레이어 바디")]
    [SerializeField] private GameObject playerBody;
    [InspectorName("플레이어 행동력 화면")]
    [SerializeField] private PlayerMPUI playerMPUI;
    [InspectorName("전투 카드 데이터베이스")]
    [SerializeField] private BattleCardDatabase battleCardDatabase;

    [Header("턴 상태 (런타임 확인용)")]
    [InspectorName("현재 턴 번호")]
    [SerializeField] private int totalTurn = 1;
    [InspectorName("플레이어 턴 여부")]
    [SerializeField] private bool isPlayerTurn = true;
    [InspectorName("이번 턴 주사위 굴림 여부")]
    [SerializeField] private bool diceRolledThisTurn = false;
    [InspectorName("현재 주사위 값")]
    [SerializeField] private int currentDiceValue = 0;

    public GameObject CurrentPlayer { get; private set; }
    public CharacterMP CurrentPlayerMP { get; private set; }
    public PlayerCombatData CurrentPlayerCombatData { get; private set; }
    public BattleCardDrawSystem CardDrawSystem { get; private set; }
    public bool CanUsePlayerCards => isPlayerTurn && diceRolledThisTurn;
    /// <summary>Player 등록이 끝난 뒤 외부 시스템에 생성된 인스턴스를 전달하는 이벤트.</summary>
    public event System.Action<GameObject> PlayerRegistered;
    /// <summary>플레이어 턴 초기화가 완료된 뒤 카드 드로우 등 후속 시스템에 알린다.</summary>
    public event System.Action PlayerTurnStarted;
    /// <summary>턴 또는 주사위 상태가 바뀌어 카드 사용 가능 여부가 변경됐을 때 알린다.</summary>
    public event System.Action<bool> CardUseAvailabilityChanged;

    /// <summary>싱글턴과 버튼 이벤트를 구성하고 카드 드로우 시스템을 자동으로 보완한다.</summary>
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        CardDrawSystem = GetComponent<BattleCardDrawSystem>();
        if (CardDrawSystem == null)
        {
            CardDrawSystem = gameObject.AddComponent<BattleCardDrawSystem>();
        }
        CardDrawSystem.ConfigureDatabase(battleCardDatabase);

        if (turnEndButton != null)
        {
            turnEndButton.onClick.RemoveListener(EndTurn);
            turnEndButton.onClick.AddListener(EndTurn);
        }

        if (diceButton != null)
        {
            diceButton.onClick.RemoveListener(RollDice);
            diceButton.onClick.AddListener(RollDice);
        }

        RefreshTurnText();
        RefreshDiceText();
        SyncTurnUI();
    }

    /// <summary>주사위를 굴린 Player 턴만 종료하고 Enemy 순차 행동을 시작한다.</summary>
    public void EndTurn()
    {
        if (!isPlayerTurn || !diceRolledThisTurn)
        {
            if (isPlayerTurn && !diceRolledThisTurn)
            {
                Debug.Log("주사위를 굴린 뒤 턴을 종료할 수 있습니다.", this);
            }

            return;
        }

        isPlayerTurn = false;
        diceRolledThisTurn = false;
        currentDiceValue = 0;
        totalTurn++;
        RefreshTurnText();
        RefreshDiceText();
        SyncTurnUI();

        StartCoroutine(TriggerEnemyTurn());
    }

    /// <summary>Enemy 전체 행동 후 Player 턴 상태와 MP·이동 상태를 초기화한다.</summary>
    public void StartPlayerTurn()
    {
        isPlayerTurn = true;
        diceRolledThisTurn = false;
        currentDiceValue = 0;
        CurrentPlayerMP?.RestoreFull();
        ResetPlayerMoveState();
        RefreshTurnText();
        RefreshDiceText();
        SyncTurnUI();
        PlayerTurnStarted?.Invoke();
    }

    /// <summary>Player Body의 마지막 자식으로 생성된 선택 캐릭터를 찾아 등록한다.</summary>
    public bool RegisterSpawnedPlayerFromBody()
    {
        if (playerBody == null)
        {
            Debug.LogError("플레이어 등록 실패: 전투 게임 관리자에 플레이어 바디 참조가 없습니다.", this);
            return false;
        }

        Transform bodyTransform = playerBody.transform;
        if (bodyTransform.childCount == 0)
        {
            Debug.LogError("플레이어 등록 실패: 플레이어 바디 아래에 생성된 캐릭터가 없습니다.", playerBody);
            return false;
        }

        // 플레이어 바디의 마지막 자식을 선택된 플레이어로 등록한다.
        RegisterPlayer(bodyTransform.GetChild(bodyTransform.childCount - 1).gameObject);
        return true;
    }

    /// <summary>
    /// 생성된 Player를 이동, Enemy 감지, MP UI에 배포한다. CharacterMP가 없으면 런타임에 보완한다.
    /// </summary>
    public void RegisterPlayer(GameObject player)
    {
        if (player == null)
        {
            Debug.LogError("플레이어 등록 실패: 전달된 플레이어가 null입니다.", this);
            return;
        }

        CurrentPlayer = player;
        InitializePlayerRuntimeData(CurrentPlayer);

        if (playerMPUI == null)
        {
            playerMPUI = FindFirstObjectByType<PlayerMPUI>(FindObjectsInactive.Include);
        }

        playerMPUI?.Bind(CurrentPlayerMP);
        CurrentPlayerMP.RestoreFull();

        RayTest[] movementControllers = FindObjectsByType<RayTest>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (RayTest movementController in movementControllers)
        {
            movementController.SetPlayer(CurrentPlayer);
        }

        EnemyDetector[] enemyDetectors = FindObjectsByType<EnemyDetector>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (EnemyDetector enemyDetector in enemyDetectors)
        {
            enemyDetector.SetPlayerTarget(CurrentPlayer.transform);
        }

        PlayerRegistered?.Invoke(CurrentPlayer);
        Debug.Log($"전투 플레이어 등록 완료: {CurrentPlayer.name}", CurrentPlayer);
    }

    /// <summary>Player 턴에 한 번만 1~3 주사위를 굴리고 RayTest 이동 범위를 연다.</summary>
    /// <summary>
    /// 스폰된 플레이어에 전투 런타임 데이터를 자동으로 구성한다.
    /// 선택 캐릭터 프리팹에 CharacterMP와 PlayerCombatData를 직접 추가할 필요가 없다.
    /// </summary>
    private void InitializePlayerRuntimeData(GameObject player)
    {
        CurrentPlayerMP = player.GetComponent<CharacterMP>();
        if (CurrentPlayerMP == null)
        {
            CurrentPlayerMP = player.AddComponent<CharacterMP>();
        }

        CurrentPlayerCombatData = player.GetComponent<PlayerCombatData>();
        if (CurrentPlayerCombatData == null)
        {
            CurrentPlayerCombatData = player.AddComponent<PlayerCombatData>();
        }

        // BattlePlayer의 공격 사거리와 위력을 전투 데이터에 반영한다.
        // 원본 공격 값이 없으면 PlayerCombatData 기본값을 사용한다.
        CurrentPlayerCombatData.RefreshFromLegacyBattlePlayer();
    }

    /// <summary>플레이어 턴에 한 번 주사위를 굴리고 결과를 이동 가능 거리로 전달한다.</summary>
    public void RollDice()
    {
        if (!isPlayerTurn || diceRolledThisTurn)
        {
            return;
        }

        diceRolledThisTurn = true;
        currentDiceValue = Random.Range(1, 4);
        SyncTurnUI();
        RefreshDiceText();

        RayTest rayTest = FindFirstObjectByType<RayTest>();
        if (rayTest != null)
        {
            rayTest.SetMoveRange(currentDiceValue);
        }
    }

    /// <summary>이동 완료 후 Debug 주사위 표시만 0으로 되돌린다.</summary>
    public void ResetDiceOnMove()
    {
        currentDiceValue = 0;
        RefreshDiceText();
    }

    /// <summary>현재 활성 Enemy를 순서대로 기다리며 실행한 후 Player 턴으로 복귀한다.</summary>
    private IEnumerator TriggerEnemyTurn()
    {
        EnemyTurnActor[] enemies = FindObjectsByType<EnemyTurnActor>(FindObjectsSortMode.None);
        foreach (EnemyTurnActor enemy in enemies)
        {
            if (enemy != null)
            {
                yield return enemy.TakeTurn();
            }
        }

        StartPlayerTurn();
    }

    /// <summary>현재 전체 턴 번호를 디버그용 턴 텍스트에 반영한다.</summary>
    private void RefreshTurnText()
    {
        if (turnDebugText != null)
        {
            turnDebugText.text = $"TURN {totalTurn}";
        }
    }

    /// <summary>현재 주사위 값을 디버그용 주사위 텍스트에 반영한다.</summary>
    private void RefreshDiceText()
    {
        if (diceDebugText != null)
        {
            diceDebugText.text = $"DICE {currentDiceValue}";
        }
    }

    /// <summary>현재 턴과 주사위 상태에 맞춰 주사위 및 턴 종료 버튼 사용 여부를 갱신한다.</summary>
    private void SyncTurnUI()
    {
        if (diceButton != null)
        {
            diceButton.interactable = isPlayerTurn && !diceRolledThisTurn;
        }

        if (turnEndButton != null)
        {
            turnEndButton.interactable = isPlayerTurn && diceRolledThisTurn;
        }

        CardUseAvailabilityChanged?.Invoke(CanUsePlayerCards);
    }

    /// <summary>플레이어 턴 시작 시 이동 입력기의 선택, 이동, 범위 표시 상태를 초기화한다.</summary>
    private void ResetPlayerMoveState()
    {
        RayTest rayTest = FindFirstObjectByType<RayTest>();
        if (rayTest != null)
        {
            rayTest.ResetTurnMoveState();
        }
    }
}
