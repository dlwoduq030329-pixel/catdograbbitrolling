using System.Collections;
using UnityEngine;

/// <summary>
/// 캐릭터 선택 Canvas에서 전투 Canvas로 넘어가는 흐름만 담당한다.
/// 맵 생성과 카메라 이동 완료 상태를 확인해 화면을 전환한다.
/// </summary>
public class BattleUIFlowController : MonoBehaviour
{
    [Header("캔버스 참조")]
    [InspectorName("플레이어 선택 캔버스")]
    [SerializeField] private GameObject playerSelectCanvas;
    [InspectorName("전투 캔버스")]
    [SerializeField] private GameObject battleCanvas;

    [Header("전환 시스템 참조")]
    [InspectorName("맵 생성기")]
    [SerializeField] private MapGenerator mapGenerator;
    [InspectorName("전투 게임 관리자")]
    [SerializeField] private BattleGameManager battleGameManager;

    [Header("카메라 전환 완료 판정")]
    [InspectorName("전환 카메라")]
    [SerializeField] private Camera transitionCamera;
    [InspectorName("카메라 정지 판정 거리")]
    [SerializeField, Min(0.0001f)] private float cameraStopThreshold = 0.01f;
    [InspectorName("정지 확인 프레임 수")]
    [SerializeField, Min(1)] private int cameraStableFrameCount = 5;
    [InspectorName("카메라 대기 제한 시간")]
    [SerializeField, Min(0.1f)] private float cameraWaitTimeout = 10f;

    private Coroutine transitionRoutine;

    /// <summary>전환 카메라를 보완하고 시작 화면을 캐릭터 선택 Canvas로 맞춘다.</summary>
    private void Awake()
    {
        if (transitionCamera == null)
        {
            transitionCamera = Camera.main;
        }

        SetCanvasState(showBattle: false);
    }

    /// <summary>캐릭터 선택 코드 수정 없이 맵 생성 상태를 관찰하는 전투 전환 절차를 시작한다.</summary>
    private void Start()
    {
        // 버튼 OnClick 연결 여부와 무관하게 캐릭터 선택 뒤 시작되는 맵 생성을 감시한다.
        BeginBattleTransition();
    }

    /// <summary>
    /// 캐릭터 확정 버튼에서도 호출할 수 있다.
    /// StatusUI.summonPlayer()와 함께 사용하면 맵 및 카메라 전환 완료 뒤 전투 UI가 열린다.
    /// </summary>
    public void BeginBattleTransition()
    {
        if (transitionRoutine != null)
        {
            return;
        }

        transitionRoutine = StartCoroutine(WaitForMapAndShowBattle());
    }

    /// <summary>맵 생성, Player 등록, 카메라 이동을 순서대로 기다린다.</summary>
    private IEnumerator WaitForMapAndShowBattle()
    {
        // 같은 버튼의 StatusUI.summonPlayer()가 MapGenerator 상태를 먼저 초기화하도록 한 Frame 양보한다.
        yield return null;

        if (mapGenerator == null)
        {
            Debug.LogError("전투 UI 전환 실패: 맵 생성기 참조가 없습니다.", this);
            transitionRoutine = null;
            yield break;
        }

        while (!mapGenerator.IsGenerateEnd())
        {
            yield return null;
        }

        if (battleGameManager == null)
        {
            Debug.LogError("전투 UI 전환 실패: 전투 게임 관리자 참조가 없습니다.", this);
            transitionRoutine = null;
            yield break;
        }

        if (!battleGameManager.RegisterSpawnedPlayerFromBody())
        {
            transitionRoutine = null;
            yield break;
        }

        yield return WaitForCameraMovementToFinish();

        SetCanvasState(showBattle: true);
        battleGameManager.StartPlayerTurn();

        transitionRoutine = null;
    }

    /// <summary>Camera 위치가 지정 Frame 동안 충분히 정지할 때까지 기다린다.</summary>
    private IEnumerator WaitForCameraMovementToFinish()
    {
        if (transitionCamera == null)
        {
            Debug.LogWarning("전환 카메라 참조가 없어 기다리지 않고 전투 UI를 표시합니다.", this);
            yield break;
        }

        // SpawnPlayer의 CameraChase.InitTarget 호출과 첫 LateUpdate 이동이 반영될 때까지 기다린다.
        yield return new WaitForEndOfFrame();

        Vector3 previousPosition = transitionCamera.transform.position;
        int stableFrames = 0;
        float elapsed = 0f;

        while (stableFrames < cameraStableFrameCount && elapsed < cameraWaitTimeout)
        {
            yield return new WaitForEndOfFrame();

            float movedDistance = Vector3.Distance(previousPosition, transitionCamera.transform.position);
            stableFrames = movedDistance <= cameraStopThreshold ? stableFrames + 1 : 0;
            previousPosition = transitionCamera.transform.position;
            elapsed += Time.unscaledDeltaTime;
        }

        if (elapsed >= cameraWaitTimeout)
        {
            Debug.LogWarning("카메라 전환 대기 시간이 초과되어 전투 UI를 표시합니다.", this);
        }
    }

    /// <summary>두 Canvas를 상호 배타적으로 전환하고 전투 카메라 입력 상태를 맞춘다.</summary>
    private void SetCanvasState(bool showBattle)
    {
        if (playerSelectCanvas != null)
        {
            playerSelectCanvas.SetActive(!showBattle);
        }

        if (battleCanvas != null)
        {
            if (showBattle && battleCanvas.transform.localScale.sqrMagnitude < 0.0001f)
            {
                battleCanvas.transform.localScale = Vector3.one;
            }

            battleCanvas.SetActive(showBattle);
        }

        ConfigureBattleCameraInput(showBattle);
    }

    /// <summary>전환 Camera에 입력 컴포넌트가 없으면 런타임에 추가하고 활성 상태를 전달한다.</summary>
    private void ConfigureBattleCameraInput(bool enabled)
    {
        if (transitionCamera == null)
        {
            return;
        }

        BattleMapCameraInput cameraInput = transitionCamera.GetComponent<BattleMapCameraInput>();
        if (cameraInput == null && enabled)
        {
            cameraInput = transitionCamera.gameObject.AddComponent<BattleMapCameraInput>();
        }

        if (cameraInput != null)
        {
            cameraInput.SetInputEnabled(enabled);
        }
    }
}
