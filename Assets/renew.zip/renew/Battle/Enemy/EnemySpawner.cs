using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// MapGenerator가 만든 Enemy 타일 위에 DB 기반 Enemy를 생성하고 필수 런타임 컴포넌트를 조립한다.
/// 적 데이터가 없으면 기본 프리팹으로 적을 생성한다.
/// </summary>
public class EnemySpawner : MonoBehaviour
{
    [Header("적 데이터베이스")]
    [InspectorName("전투 적 데이터베이스")]
    [SerializeField] private BattleEnemyDatabase enemyDatabase;
    [InspectorName("데이터 항목 무작위 선택")]
    [SerializeField] private bool useRandomDatabaseEntry = true;
    [InspectorName("고정 데이터 인덱스")]
    [SerializeField, Min(0)] private int databaseIndex;

    [Header("데이터베이스 미연결 호환 설정")]
    [InspectorName("기본 적 프리팹")]
    [SerializeField] private GameObject enemyPrefab;

    private readonly List<GameObject> spawnedEnemies = new List<GameObject>();

    public IReadOnlyList<GameObject> SpawnedEnemies => spawnedEnemies;

    /// <summary>
    /// 지정된 Enemy 타일에 Enemy를 생성하고 Detector, TurnActor, Awareness, MP 등을 보장한다.
    /// </summary>
    public GameObject SpawnEnemy(Transform enemyTile)
    {
        if (enemyTile == null)
        {
            Debug.LogError("적 생성 실패: 적 타일 참조가 없습니다.", this);
            return null;
        }

        BattleEnemyData selectedData = SelectEnemyData();
        GameObject selectedPrefab = selectedData != null ? selectedData.prefab : enemyPrefab;

        if (selectedPrefab == null)
        {
            Debug.LogError("적 생성 실패: DB 데이터와 기본 프리팹이 모두 없습니다.", this);
            return null;
        }

        GameObject enemy = Instantiate(
            selectedPrefab,
            enemyTile.position,
            Quaternion.identity,
            enemyTile);

        EnemyDetector detector = enemy.GetComponentInChildren<EnemyDetector>();
        if (detector == null)
        {
            detector = enemy.AddComponent<EnemyDetector>();
            Debug.LogWarning(
                $"{enemy.name} 프리팹에 EnemyDetector가 없어 런타임에 기본 컴포넌트를 추가했습니다.",
                enemy);
        }

        if (selectedData != null)
        {
            detector.ConfigureDetectRange(selectedData.detectRange);
        }

        EnemyTurnActor turnActor = enemy.GetComponent<EnemyTurnActor>();
        if (turnActor == null)
        {
            turnActor = enemy.AddComponent<EnemyTurnActor>();
        }

        EnemyAwareness awareness = enemy.GetComponent<EnemyAwareness>();
        if (awareness == null)
        {
            awareness = enemy.AddComponent<EnemyAwareness>();
        }

        if (enemy.GetComponent<PathDebugView>() == null)
        {
            enemy.AddComponent<PathDebugView>();
        }

        CharacterMP enemyMP = enemy.GetComponent<CharacterMP>();
        if (enemyMP == null)
        {
            enemyMP = enemy.AddComponent<CharacterMP>();
        }

        if (selectedData != null)
        {
            BattleEnemyRuntimeData runtimeData = enemy.GetComponent<BattleEnemyRuntimeData>();
            if (runtimeData == null)
            {
                runtimeData = enemy.AddComponent<BattleEnemyRuntimeData>();
            }

            runtimeData.Initialize(selectedData);
            turnActor.ConfigureFromData(selectedData);
            awareness.ConfigureAlertRange(selectedData.alertRange);

            enemyMP.ConfigureFixedMaxMP(selectedData.maxMP);
        }

        spawnedEnemies.Add(enemy);
        return enemy;
    }

    /// <summary>파괴된 Enemy 참조를 생성 목록에서 제거한다.</summary>
    public void ClearMissingEnemyReferences()
    {
        spawnedEnemies.RemoveAll(enemy => enemy == null);
    }

    /// <summary>설정에 따라 DB의 무작위 항목 또는 고정 인덱스 항목을 선택한다.</summary>
    private BattleEnemyData SelectEnemyData()
    {
        if (enemyDatabase == null || enemyDatabase.Count == 0)
        {
            return null;
        }

        return useRandomDatabaseEntry
            ? enemyDatabase.GetRandom()
            : enemyDatabase.GetAt(databaseIndex);
    }
}
