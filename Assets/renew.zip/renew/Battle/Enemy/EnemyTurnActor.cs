using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enemy 턴 한 번을 실행하는 행동 어댑터다.
/// BT에는 판단만 요청하고, 경로 이동과 타일별 MP 차감은 이 컴포넌트가 수행한다.
/// </summary>
public class EnemyTurnActor : MonoBehaviour
{
    [Header("적 이동 및 공격 설정")]
    [InspectorName("한 칸 이동 시간")]
    [SerializeField, Min(0.01f)] private float secondsPerTile = 0.2f;
    [InspectorName("공격 사거리 (칸)")]
    [SerializeField, Min(1)] private int attackRangeTiles = 1;
    [InspectorName("턴당 최대 행동 트리 평가 횟수")]
    [SerializeField, Min(1)] private int maxTreeEvaluationsPerTurn = 16;

    private EnemyDetector detector;
    private EnemyAwareness awareness;
    private PathDebugView pathDebugView;
    private CharacterMP characterMP;
    private BattleEnemyRuntimeData runtimeData;
    private BehaviorNode behaviorTree;

    /// <summary>Spawner가 선택한 DB 데이터 중 행동 판단에 필요한 값을 적용한다.</summary>
    public void ConfigureFromData(BattleEnemyData data)
    {
        if (data == null)
        {
            return;
        }

        attackRangeTiles = Mathf.Max(1, data.attackRangeTiles);
    }

    /// <summary>적 행동에 필요한 감지, 인식, 경로 표시 참조와 공용 행동 트리를 준비한다.</summary>
    private void Awake()
    {
        detector = GetComponentInChildren<EnemyDetector>();
        awareness = GetComponent<EnemyAwareness>();
        pathDebugView = GetComponent<PathDebugView>();
        behaviorTree = EnemyBehaviorTreeFactory.CreateAggressiveTree();
    }

    /// <summary>
    /// MP 회복, Target 확인, 경로 계산, BT 평가, 선택된 행동 실행 순으로 Enemy 턴을 처리한다.
    /// </summary>
    public IEnumerator TakeTurn()
    {
        ResolveComponents();
        characterMP?.RestoreFull();
        int basicAttackCount = 0;

        for (int evaluation = 0; evaluation < maxTreeEvaluationsPerTurn; evaluation++)
        {
            Transform target = ResolveTarget();
            if (target == null)
            {
                pathDebugView?.Clear();
                yield break;
            }

            MapInfo[] mapTiles = FindObjectsByType<MapInfo>(FindObjectsSortMode.None);
            MapInfo startTile = MapPathfinder.FindClosestTile(transform.position, mapTiles);
            MapInfo targetTile = MapPathfinder.FindClosestTile(target.position, mapTiles);
            HashSet<MapInfo> occupiedTiles = FindOtherEnemyTiles(mapTiles);

            if (!MapPathfinder.TryFindShortestPath(startTile, targetTile, occupiedTiles, out List<MapInfo> path))
            {
                Debug.LogWarning($"{name}: 플레이어까지 이어지는 경로를 찾지 못했습니다.", this);
                pathDebugView?.Clear();
                yield break;
            }

            pathDebugView?.DrawPath(transform.position, path);

            int moveCostPerTile = GetMoveCostPerTile();
            int basicAttackCost = GetBasicAttackCost(basicAttackCount);
            EnemyAIContext context = new EnemyAIContext(
                transform,
                target,
                startTile,
                targetTile,
                path,
                attackRangeTiles,
                characterMP.CurrentMP,
                moveCostPerTile,
                basicAttackCost);

            behaviorTree.Evaluate(context);
            int mpBeforeAction = characterMP.CurrentMP;

            switch (context.Decision)
            {
                case EnemyAIDecision.Move:
                    yield return MoveAlongPath(path, startTile, moveCostPerTile);
                    break;

                case EnemyAIDecision.Attack:
                    if (!characterMP.TrySpend(basicAttackCost))
                    {
                        yield break;
                    }

                    basicAttackCount++;
                    // 실제 피해 적용은 후속 Character/CombatSystem 어댑터가 담당한다.
                    Debug.Log(
                        $"{name}: 기본 공격 {basicAttackCount}회차 선택, " +
                        $"MP {basicAttackCost} 소모, 남은 MP {characterMP.CurrentMP}",
                        this);
                    break;

                default:
                    yield break;
            }

            // 행동이 MP를 소비하지 않으면 같은 판단이 무한 반복될 수 있으므로 턴을 종료한다.
            if (characterMP.CurrentMP >= mpBeforeAction)
            {
                yield break;
            }
        }

        Debug.LogWarning($"{name}: 행동 트리 최대 평가 횟수에 도달하여 턴을 종료합니다.", this);
    }

    /// <summary>기억 중인 Target을 우선 사용하고, 없으면 Detector의 직접 감지 결과를 확인한다.</summary>
    private Transform ResolveTarget()
    {
        if (awareness != null && awareness.HasTarget)
        {
            return awareness.Target;
        }

        Transform detectedTarget = detector != null ? detector.PlayerTarget : null;
        if (detectedTarget != null && detector.CanDetectPlayer(detectedTarget))
        {
            awareness?.SetTarget(detectedTarget);
            return detectedTarget;
        }

        return null;
    }

    /// <summary>
    /// 현재 MP로 지불 가능한 만큼 공격 사거리 직전까지 이동하고, 타일 도착마다 MP를 차감한다.
    /// </summary>
    private IEnumerator MoveAlongPath(
        IReadOnlyList<MapInfo> path,
        MapInfo startTile,
        int moveCostPerTile)
    {
        int affordableTiles = characterMP != null
            ? characterMP.CurrentMP / moveCostPerTile
            : 0;
        int moveCount = Mathf.Min(affordableTiles, Mathf.Max(0, path.Count - attackRangeTiles));
        if (moveCount == 0 || startTile == null)
        {
            yield break;
        }

        float heightOffset = transform.position.y - startTile.transform.position.y;

        for (int i = 0; i < moveCount; i++)
        {
            Vector3 startPosition = transform.position;
            Vector3 targetPosition = path[i].transform.position + Vector3.up * heightOffset;
            float elapsed = 0f;

            while (elapsed < secondsPerTile)
            {
                elapsed += Time.deltaTime;
                transform.position = Vector3.Lerp(
                    startPosition,
                    targetPosition,
                    Mathf.Clamp01(elapsed / secondsPerTile));
                yield return null;
            }

            transform.position = targetPosition;

            if (characterMP != null && !characterMP.TrySpend(moveCostPerTile))
            {
                Debug.LogWarning($"{name}: MP 차감에 실패하여 이동을 중단했습니다.", this);
                yield break;
            }
        }
    }

    /// <summary>DB에 설정된 타일당 이동 MP 비용을 반환하며 DB가 없으면 1을 사용한다.</summary>
    private int GetMoveCostPerTile()
    {
        return runtimeData != null && runtimeData.Data != null
            ? Mathf.Max(1, runtimeData.Data.moveMPCostPerTile)
            : 1;
    }

    /// <summary>이번 턴 기본 공격 순번에 따라 기본 비용을 누적 배율로 계산한다.</summary>
    private int GetBasicAttackCost(int successfulAttackCount)
    {
        int baseCost = runtimeData != null && runtimeData.Data != null
            ? Mathf.Max(0, runtimeData.Data.basicAttackMPCost)
            : 1;
        return baseCost * (successfulAttackCount + 1);
    }

    /// <summary>다른 Enemy가 현재 점유한 타일을 이번 경로 탐색의 장애물로 수집한다.</summary>
    private HashSet<MapInfo> FindOtherEnemyTiles(MapInfo[] mapTiles)
    {
        HashSet<MapInfo> occupiedTiles = new HashSet<MapInfo>();
        EnemyTurnActor[] enemies = FindObjectsByType<EnemyTurnActor>(FindObjectsSortMode.None);

        foreach (EnemyTurnActor enemy in enemies)
        {
            if (enemy == null || enemy == this || !enemy.gameObject.activeInHierarchy)
            {
                continue;
            }

            MapInfo occupiedTile = MapPathfinder.FindClosestTile(enemy.transform.position, mapTiles);
            if (occupiedTile != null)
            {
                occupiedTiles.Add(occupiedTile);
            }
        }

        return occupiedTiles;
    }

    /// <summary>런타임 자동 부착 순서와 무관하게 필요한 컴포넌트 참조를 다시 확보한다.</summary>
    private void ResolveComponents()
    {
        if (detector == null)
            detector = GetComponentInChildren<EnemyDetector>();
        if (awareness == null)
            awareness = GetComponent<EnemyAwareness>();
        if (pathDebugView == null)
            pathDebugView = GetComponent<PathDebugView>();
        if (characterMP == null)
            characterMP = GetComponent<CharacterMP>();
        if (characterMP == null)
            characterMP = gameObject.AddComponent<CharacterMP>();
        if (runtimeData == null)
            runtimeData = GetComponent<BattleEnemyRuntimeData>();
        if (behaviorTree == null)
            behaviorTree = EnemyBehaviorTreeFactory.CreateAggressiveTree();
    }
}
