using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// 전투 맵의 확대/축소, 드래그, 키보드, 화면 가장자리 이동 입력을 CameraChase에 전달한다.
/// Space를 누르는 동안 수동 오프셋을 초기화해 Player를 계속 화면 중심에 고정한다.
/// </summary>
public class BattleMapCameraInput : MonoBehaviour
{
    [Header("카메라 이동 입력")]
    [InspectorName("가운데 버튼 드래그 속도")]
    [SerializeField] private float dragPanSpeed = 0.02f;
    [InspectorName("키보드 이동 속도")]
    [SerializeField] private float keyboardPanSpeed = 12f;
    [InspectorName("화면 가장자리 이동 사용")]
    [SerializeField] private bool useEdgePan = true;
    [InspectorName("화면 가장자리 감지 두께")]
    [SerializeField] private float edgeSize = 18f;
    [InspectorName("화면 가장자리 이동 속도")]
    [SerializeField] private float edgePanSpeed = 12f;

    [Header("카메라 확대 및 축소")]
    [InspectorName("마우스 휠 확대/축소 속도")]
    [SerializeField] private float zoomSpeed = 2f;

    private CameraChase cameraChase;
    private Vector3 previousMousePosition;
    private bool inputEnabled;

    /// <summary>씬 참조가 비어 있으면 주 카메라와 추적 컴포넌트를 자동으로 찾는다.</summary>
    private void Awake()
    {
        cameraChase = GetComponent<CameraChase>();
    }

    /// <summary>전투 입력이 허용된 동안 확대, 드래그, 키보드, 화면 가장자리 이동을 처리한다.</summary>
    private void Update()
    {
        if (!inputEnabled || cameraChase == null)
        {
            return;
        }

        HandleZoom();

        if (Input.GetKey(KeyCode.Space))
        {
            cameraChase.ResetManualView();
            return;
        }

        HandleMiddleMouseDrag();
        HandleKeyboardPan();
        HandleEdgePan();

        if (Input.GetKeyDown(KeyCode.Home))
        {
            cameraChase.ResetManualView();
        }
    }

    /// <summary>Battle Canvas 전환 상태에 맞춰 카메라 수동 입력을 켜거나 끈다.</summary>
    public void SetInputEnabled(bool enabled)
    {
        inputEnabled = enabled;
        previousMousePosition = Input.mousePosition;
    }

    /// <summary>마우스 휠 입력으로 직교 카메라 크기를 제한 범위 안에서 변경한다.</summary>
    private void HandleZoom()
    {
        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }

        float scroll = Input.mouseScrollDelta.y;
        if (!Mathf.Approximately(scroll, 0f))
        {
            cameraChase.AddZoom(-scroll * zoomSpeed);
        }
    }

    /// <summary>마우스 가운데 버튼 드래그량을 카메라 평면 이동량으로 변환한다.</summary>
    private void HandleMiddleMouseDrag()
    {
        if (Input.GetMouseButtonDown(2))
        {
            previousMousePosition = Input.mousePosition;
        }

        if (!Input.GetMouseButton(2))
        {
            return;
        }

        Vector3 mousePosition = Input.mousePosition;
        Vector3 mouseDelta = mousePosition - previousMousePosition;
        float zoomScale = Mathf.Max(1f, cameraChase.CurrentZoomHeight / 10f);
        cameraChase.AddPan(new Vector3(
            -mouseDelta.x * dragPanSpeed * zoomScale,
            0f,
            -mouseDelta.y * dragPanSpeed * zoomScale));
        previousMousePosition = mousePosition;
    }

    /// <summary>설정된 방향키 입력으로 카메라의 수동 이동 보정값을 변경한다.</summary>
    private void HandleKeyboardPan()
    {
        Vector3 direction = new Vector3(
            Input.GetAxisRaw("Horizontal"),
            0f,
            Input.GetAxisRaw("Vertical"));

        if (direction.sqrMagnitude > 0f)
        {
            cameraChase.AddPan(direction.normalized * keyboardPanSpeed * Time.unscaledDeltaTime);
        }
    }

    /// <summary>마우스가 화면 가장자리에 있을 때 해당 방향으로 카메라를 이동한다.</summary>
    private void HandleEdgePan()
    {
        if (!useEdgePan || Input.GetMouseButton(2))
        {
            return;
        }

        Vector3 mousePosition = Input.mousePosition;
        Vector3 direction = Vector3.zero;

        if (mousePosition.x <= edgeSize)
            direction.x = -1f;
        else if (mousePosition.x >= Screen.width - edgeSize)
            direction.x = 1f;

        if (mousePosition.y <= edgeSize)
            direction.z = -1f;
        else if (mousePosition.y >= Screen.height - edgeSize)
            direction.z = 1f;

        if (direction.sqrMagnitude > 0f)
        {
            cameraChase.AddPan(direction.normalized * edgePanSpeed * Time.unscaledDeltaTime);
        }
    }
}
