using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Player 클릭부터 이동/공격 범위 표시, 목적지 또는 Enemy 선택, 확정/취소까지 담당하는 입력 Controller다.
/// MapInfo의 상하좌우 연결을 사용하며 확정된 이동 경로 1칸당 행동력 1을 차감한다.
/// </summary>
public class RayTest : MonoBehaviour
{
    public static bool IsMoveRangeVisible { get; private set; }
    public static event System.Action<bool> MoveRangeVisibilityChanged;

    [Header("필수 참조")]
    [InspectorName("메인 카메라")]
    public Camera mainCamera;
    [InspectorName("플레이어")]
    public GameObject player;
    [InspectorName("이동 확정 버튼")]
    public Button confirmMoveButton;
    [InspectorName("이동 선택 취소 버튼")]
    public Button quitMoveButton;
    [InspectorName("이동 버튼 묶음")]
    public GameObject moveButtonGroup;
    [InspectorName("행동 확인 안내 텍스트 (선택 사항)")]
    [SerializeField] private TMP_Text actionConfirmText;

    [Header("이동 범위")]
    [InspectorName("최소 이동 범위")]
    public int minMoveRange = 1;
    [InspectorName("최대 이동 범위")]
    public int maxMoveRange = 3;
    [InspectorName("현재 이동 범위")]
    public int currentMoveRange = 3;

    [Header("레이캐스트 설정")]
    [InspectorName("타일 레이어 마스크")]
    public LayerMask tileLayerMask = ~0;

    [Header("이동 연출 시간")]
    [InspectorName("타일당 기본 이동 시간")]
    public float secondsPerTile = 1f;
    [InspectorName("이동 속도 배율")]
    public float moveSpeedMultiplier = 4f;

    [Header("이동 범위 색상")]
    [InspectorName("이동 가능 타일 색상")]
    public Color movableTileColor = new Color(0.25f, 0.9f, 0.25f, 1f);
    [InspectorName("이동 불가 타일 색상")]
    public Color blockedTileColor = new Color(0.9f, 0.2f, 0.2f, 1f);
    [InspectorName("적 감지 범위 타일 색상")]
    public Color enemyDetectColor = new Color(1f, 0.6f, 0.15f, 1f);
    [InspectorName("선택 타일 색상")]
    public Color selectedTileColor = new Color(1f, 0.95f, 0.35f, 1f);
    [InspectorName("도착 타일 색상")]
    public Color landedTileColor = new Color(0.55f, 1f, 0.85f, 1f);
    [InspectorName("이동 후 공격 가능 타일 색상")]
    public Color attackableTileColor = new Color(0.9f, 0.2f, 0.25f, 1f);
    [InspectorName("카드 사용 가능 타일 색상")]
    public Color cardRangeTileColor = new Color(0.35f, 0.45f, 1f, 1f);
    [Header("이동 범위 가시성 조절")]
    [InspectorName("범위 색상 혼합 강도")]
    [SerializeField, Range(0f, 1f)] private float rangeColorBlend = 0.3f;
    [InspectorName("선택 타일 색상 혼합 강도")]
    [SerializeField, Range(0f, 1f)] private float selectedColorBlend = 0.65f;
    [InspectorName("도착 타일 색상 혼합 강도")]
    [SerializeField, Range(0f, 1f)] private float landedColorBlend = 0.5f;
    [InspectorName("도착 타일 강조 시간")]
    public float landedHighlightDuration = 0.6f;
    [InspectorName("이동 화살표 프리팹")]
    public GameObject moveArrowPrefab;
    [InspectorName("화살표 위치 보정값")]
    public Vector3 arrowOffset = new Vector3(0f, 0.45f, 0f);

    private readonly List<MapInfo> cachedMapTiles = new List<MapInfo>();
    private readonly HashSet<MapInfo> reachableTiles = new HashSet<MapInfo>();
    private readonly HashSet<MapInfo> attackableTiles = new HashSet<MapInfo>();
    private readonly Dictionary<MapInfo, int> reachableDistances = new Dictionary<MapInfo, int>();
    private readonly HashSet<MapInfo> occupiedEnemyTiles = new HashSet<MapInfo>();
    private readonly HashSet<MapInfo> cardRangeTiles = new HashSet<MapInfo>();
    private readonly Dictionary<Renderer, Color> originalColors = new Dictionary<Renderer, Color>();

    private bool rangeVisible;
    private bool isMoving;
    private bool diceRolledThisTurn;
    private bool movementUsedThisTurn;
    private bool awaitingConfirm;
    private bool awaitingActionConfirm;
    private bool awaitingCardConfirm;
    private bool awaitingCardTarget;
    private MapInfo selectedMoveTile;
    private MapInfo landedMoveTile;
    private Coroutine landedHighlightRoutine;
    private GameObject moveArrowInstance;
    private PlayerCombatData playerCombatData;
    private BattleActionRequest pendingAction;
    private EnemyTurnActor pendingEnemy;
    private List<MapInfo> pendingMovementPath = new List<MapInfo>();
    private MapInfo pendingOriginalTile;
    private Vector3 pendingOriginalPosition;
    private int basicAttackCountThisTurn;
    private PendingBattleCardUse pendingCardUse;
    private BattleCardDrawSystem pendingCardDrawSystem;
    private GameObject pendingCardTarget;
    private MapInfo pendingCardTargetTile;

    /// <summary>확정된 행동 결과를 구독자에게 전달하는 이벤트.</summary>
    public event System.Action<BattleActionResult> ActionConfirmed;

    /// <summary>카메라와 확인 화면 참조를 보완하고 확인·취소 버튼 이벤트를 연결한다.</summary>
    private void Awake()
    {
        RefreshCamera();

        if (moveButtonGroup == null)
        {
            moveButtonGroup = FindGameObjectByName("Move Bu");
        }

        if (quitMoveButton == null)
        {
            quitMoveButton = FindButtonByName("Quit");
        }

        if (actionConfirmText == null)
        {
            actionConfirmText = FindTextByName("ExplaneText");
        }

        if (confirmMoveButton != null)
        {
            confirmMoveButton.onClick.RemoveListener(ConfirmMove);
            confirmMoveButton.onClick.AddListener(ConfirmMove);
            confirmMoveButton.interactable = false;
        }

        if (quitMoveButton != null)
        {
            quitMoveButton.onClick.RemoveListener(CancelMoveSelection);
            quitMoveButton.onClick.AddListener(CancelMoveSelection);
            quitMoveButton.interactable = false;
        }

        SetMoveButtonGroupVisible(false);
    }

    /// <summary>맵 생성 후 사용할 타일 목록과 원본 표시 상태를 처음 수집한다.</summary>
    private void Start()
    {
        RefreshMapTiles();
    }

    /// <summary>매 프레임 취소, 플레이어 선택, 목적지 및 적 대상 선택 입력을 순서대로 처리한다.</summary>
    private void Update()
    {
        HandleCancelInput();
        HandleLeftClick();
        HandleRightClick();
    }

    /// <summary>BattleGameManager가 생성된 실제 Player 인스턴스를 전달한다.</summary>
    public void SetPlayer(GameObject targetPlayer)
    {
        player = targetPlayer;
        playerCombatData = player != null ? player.GetComponent<PlayerCombatData>() : null;
        if (player != null && playerCombatData == null)
        {
            Debug.LogError("플레이어 전투 데이터가 초기화되지 않았습니다. BattleGameManager를 통해 플레이어를 등록해야 합니다.", player);
        }

        Debug.Log(targetPlayer != null
            ? $"이동 시스템 플레이어 등록 완료: {targetPlayer.name}"
            : "이동 시스템의 플레이어 참조를 해제했습니다.", this);
    }

    /// <summary>주사위 결과를 이번 턴 이동 상한으로 저장하고 이동 입력을 허용한다.</summary>
    public void SetMoveRange(int moveRange)
    {
        currentMoveRange = Mathf.Clamp(moveRange, minMoveRange, maxMoveRange);
        diceRolledThisTurn = true;
        Debug.Log($"이동 범위 설정: {currentMoveRange}칸", this);
    }

    /// <summary>현재 선택된 목적지가 유효하면 실제 이동 Coroutine을 시작한다.</summary>
    public void ConfirmMove()
    {
        if (awaitingCardConfirm)
        {
            ConfirmPendingCardUse();
            return;
        }

        if (awaitingActionConfirm)
        {
            ConfirmPendingAction();
            return;
        }

        if (!awaitingConfirm || selectedMoveTile == null || !diceRolledThisTurn || movementUsedThisTurn)
        {
            return;
        }

        SetMoveButtonGroupVisible(false);
        StartCoroutine(MovePlayerToTile(selectedMoveTile));
    }

    /// <summary>새 Player 턴에 주사위, 이동 사용, 선택, 표시 상태를 전부 초기화한다.</summary>
    public void ResetTurnMoveState()
    {
        diceRolledThisTurn = false;
        movementUsedThisTurn = false;
        awaitingConfirm = false;
        awaitingActionConfirm = false;
        awaitingCardConfirm = false;
        awaitingCardTarget = false;
        basicAttackCountThisTurn = 0;
        selectedMoveTile = null;
        landedMoveTile = null;
        reachableTiles.Clear();
        attackableTiles.Clear();
        reachableDistances.Clear();
        occupiedEnemyTiles.Clear();
        ClearPendingAction();
        ClearPendingCardUse();
        ClearMoveArrow();
        ClearMoveRange();

        if (confirmMoveButton != null)
        {
            confirmMoveButton.interactable = false;
        }


        if (quitMoveButton != null)
        {
            quitMoveButton.interactable = false;
        }

        SetMoveButtonGroupVisible(false);
    }

    /// <summary>ESC 입력을 현재 단계에 맞는 취소 동작으로 전달한다.</summary>
    private void HandleCancelInput()
    {
        if (!isMoving && Input.GetKeyDown(KeyCode.Escape))
        {
            CancelMoveSelection();
        }
    }

    /// <summary>Player 클릭으로 범위를 열고, 범위 밖 클릭으로 현재 단계를 취소한다.</summary>
    private void HandleLeftClick()
    {
        if (!Input.GetMouseButtonDown(0) || isMoving)
        {
            return;
        }

        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }

        if (TryRaycastPlayer(out GameObject clickedPlayer))
        {
            if (awaitingConfirm || awaitingActionConfirm || awaitingCardConfirm || awaitingCardTarget)
            {
                return;
            }

            Debug.Log($"플레이어 클릭: {clickedPlayer.name}, 주사위 굴림={diceRolledThisTurn}", clickedPlayer);

            if (!diceRolledThisTurn)
            {
                Debug.Log("이동 범위를 표시하려면 먼저 주사위를 굴려야 합니다.", this);
                return;
            }

            ShowMoveRange();
            return;
        }

        if (rangeVisible)
        {
            bool clickedReachableTile =
                TryRaycastMapTile(out MapInfo clickedTile) && reachableTiles.Contains(clickedTile);

            if (!clickedReachableTile)
            {
                CancelMoveSelection();
            }
        }
    }

    /// <summary>이동 가능 타일 우클릭으로 목적지를 선택하며 범위 밖 우클릭은 취소한다.</summary>
    private void HandleRightClick()
    {
        if (awaitingCardTarget)
        {
            HandleCardTargetRightClick();
            return;
        }

        if (!Input.GetMouseButtonDown(1) || !diceRolledThisTurn || !rangeVisible ||
            isMoving || awaitingConfirm || awaitingActionConfirm || awaitingCardConfirm)
        {
            return;
        }

        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }

        if (TryRaycastEnemy(out EnemyTurnActor enemy))
        {
            TryBeginBasicAttack(enemy);
            return;
        }

        if (!movementUsedThisTurn &&
            TryRaycastMapTile(out MapInfo tile) && reachableTiles.Contains(tile))
        {
            SelectMoveTile(tile);
            return;
        }

        CancelMoveSelection();
    }

    /// <summary>카드 대상 유형에 맞는 적 또는 타일을 우클릭으로 선택한다.</summary>
    private void HandleCardTargetRightClick()
    {
        if (!Input.GetMouseButtonDown(1) || isMoving)
        {
            return;
        }

        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }

        BattleCardTargetType targetType = pendingCardUse.CardData.targetType;
        if ((targetType == BattleCardTargetType.Enemy || targetType == BattleCardTargetType.Character) &&
            TryRaycastEnemy(out EnemyTurnActor enemy))
        {
            MapInfo enemyTile = FindClosestMapTile(enemy.transform.position);
            if (enemyTile != null && cardRangeTiles.Contains(enemyTile))
            {
                SelectCardTarget(enemy.gameObject, enemyTile);
                return;
            }
        }

        if (targetType == BattleCardTargetType.Tile &&
            TryRaycastMapTile(out MapInfo tile) && cardRangeTiles.Contains(tile))
        {
            SelectCardTarget(tile.gameObject, tile);
            return;
        }

        Debug.Log("카드 사거리 안의 올바른 대상을 선택해야 합니다.", this);
    }

    /// <summary>Player 본체 또는 자식 Collider가 클릭됐는지 검사한다.</summary>
    private bool TryRaycastPlayer(out GameObject clickedPlayer)
    {
        clickedPlayer = null;
        RefreshCamera();

        if (mainCamera == null || player == null)
        {
            return false;
        }

        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
        RaycastHit[] hits = Physics.RaycastAll(ray, 500f, ~0, QueryTriggerInteraction.Collide);

        foreach (RaycastHit hit in hits)
        {
            Transform hitTransform = hit.collider.transform;
            if (hitTransform == player.transform || hitTransform.IsChildOf(player.transform))
            {
                clickedPlayer = player;
                return true;
            }
        }

        return false;
    }

    /// <summary>마우스 아래 Collider의 부모에서 활성 EnemyTurnActor를 찾는다.</summary>
    private bool TryRaycastEnemy(out EnemyTurnActor enemy)
    {
        enemy = null;
        RefreshCamera();

        if (mainCamera == null)
        {
            return false;
        }

        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
        RaycastHit[] hits = Physics.RaycastAll(ray, 500f, ~0, QueryTriggerInteraction.Collide);
        foreach (RaycastHit hit in hits)
        {
            enemy = hit.collider.GetComponentInParent<EnemyTurnActor>();
            if (enemy != null && enemy.gameObject.activeInHierarchy)
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>마우스 아래 충돌체의 부모에서 MapInfo를 찾는다.</summary>
    private bool TryRaycastMapTile(out MapInfo tile)
    {
        tile = null;
        RefreshCamera();

        if (mainCamera == null)
        {
            return false;
        }

        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
        RaycastHit[] hits = Physics.RaycastAll(ray, 500f, tileLayerMask, QueryTriggerInteraction.Collide);

        foreach (RaycastHit hit in hits)
        {
            tile = hit.collider.GetComponentInParent<MapInfo>();
            if (tile != null)
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// 주사위 범위와 현재 MP 중 작은 값으로 BFS 범위를 계산하고 타일 색상을 표시한다.
    /// </summary>
    private void ShowMoveRange()
    {
        RefreshMapTiles();
        RestoreAllTileColors();
        reachableTiles.Clear();
        attackableTiles.Clear();
        reachableDistances.Clear();
        RefreshOccupiedEnemyTiles();

        MapInfo currentTile = FindClosestMapTile(player != null ? player.transform.position : Vector3.zero);
        if (currentTile == null)
        {
            Debug.LogWarning("플레이어가 서 있는 맵 타일을 찾지 못했습니다.", this);
            SetRangeVisible(false);
            return;
        }

        CharacterMP playerMP = player != null ? player.GetComponent<CharacterMP>() : null;
        int mpLimitedRange = playerMP != null && !movementUsedThisTurn
            ? Mathf.Min(currentMoveRange, playerMP.CurrentMP)
            : 0;
        BuildReachableTiles(currentTile, mpLimitedRange);
        BuildAttackableTiles(currentTile, GetPlayerAttackRange());

        foreach (MapInfo tile in cachedMapTiles)
        {
            if (tile == null)
            {
                continue;
            }

            if (!IsWalkable(tile))
            {
                SetTileColor(tile, blockedTileColor);
            }
            else if (reachableTiles.Contains(tile))
            {
                SetTileColor(tile, movableTileColor);
            }
            else if (attackableTiles.Contains(tile))
            {
                SetTileColor(tile, attackableTileColor);
            }
            else if (IsInAnyEnemyDetectRange(tile.transform.position))
            {
                SetTileColor(tile, enemyDetectColor);
            }
        }

        SetRangeVisible(true);
    }

    /// <summary>시작 타일에서 maxDistance 이하로 도달 가능한 타일을 BFS로 수집한다.</summary>
    private void BuildReachableTiles(MapInfo startTile, int maxDistance)
    {
        Queue<MapInfo> queue = new Queue<MapInfo>();

        queue.Enqueue(startTile);
        reachableDistances[startTile] = 0;

        while (queue.Count > 0)
        {
            MapInfo current = queue.Dequeue();
            int distance = reachableDistances[current];

            if (distance >= maxDistance)
            {
                continue;
            }

            foreach (MapInfo neighbour in GetNeighbours(current))
            {
                if (neighbour == null ||
                    reachableDistances.ContainsKey(neighbour) ||
                    !IsWalkable(neighbour) ||
                    occupiedEnemyTiles.Contains(neighbour))
                {
                    continue;
                }

                int nextDistance = distance + 1;
                reachableDistances[neighbour] = nextDistance;
                reachableTiles.Add(neighbour);
                queue.Enqueue(neighbour);
            }
        }
    }

    /// <summary>
    /// 현재 타일과 모든 이동 도착점에서 공격 가능한 타일 합집합을 만들고 이동 영역은 제외한다.
    /// </summary>
    private void BuildAttackableTiles(MapInfo currentTile, int attackRange)
    {
        HashSet<MapInfo> origins = new HashSet<MapInfo>(reachableTiles) { currentTile };

        foreach (MapInfo origin in origins)
        {
            Queue<MapInfo> queue = new Queue<MapInfo>();
            Dictionary<MapInfo, int> distances = new Dictionary<MapInfo, int>();
            queue.Enqueue(origin);
            distances[origin] = 0;

            while (queue.Count > 0)
            {
                MapInfo current = queue.Dequeue();
                int distance = distances[current];

                if (distance > 0)
                {
                    attackableTiles.Add(current);
                }

                if (distance >= attackRange)
                {
                    continue;
                }

                foreach (MapInfo neighbour in GetNeighbours(current))
                {
                    if (neighbour == null || distances.ContainsKey(neighbour))
                    {
                        continue;
                    }

                    distances[neighbour] = distance + 1;
                    queue.Enqueue(neighbour);
                }
            }
        }

        attackableTiles.ExceptWith(reachableTiles);
        attackableTiles.Remove(currentTile);
    }

    /// <summary>MapInfo가 보유한 상하좌우 인접 타일을 순서대로 반환한다.</summary>
    private IEnumerable<MapInfo> GetNeighbours(MapInfo tile)
    {
        yield return tile.Up;
        yield return tile.Down;
        yield return tile.Left;
        yield return tile.Right;
    }

    /// <summary>타일 유형과 이동 가능 값을 사용해 플레이어가 진입 가능한지 검사한다.</summary>
    private bool IsWalkable(MapInfo tile)
    {
        if (tile == null)
        {
            return false;
        }

        // 시작 타일은 IsWalkable 값과 관계없이 이동 가능 타일로 처리한다.
        return tile.IsWalkable || tile.Type == TileType.Start;
    }

    /// <summary>월드 좌표와 XZ 평면상 가장 가까운 MapInfo 타일을 찾는다.</summary>
    private MapInfo FindClosestMapTile(Vector3 worldPosition)
    {
        MapInfo closest = null;
        float closestSqrDistance = float.MaxValue;

        foreach (MapInfo tile in cachedMapTiles)
        {
            if (tile == null)
            {
                continue;
            }

            Vector2 delta = new Vector2(
                tile.transform.position.x - worldPosition.x,
                tile.transform.position.z - worldPosition.z);
            float sqrDistance = delta.sqrMagnitude;

            if (sqrDistance < closestSqrDistance)
            {
                closestSqrDistance = sqrDistance;
                closest = tile;
            }
        }

        return closest;
    }

    /// <summary>현재 PlayerCombatData의 기본 공격 사거리를 반환한다.</summary>
    private int GetPlayerAttackRange()
    {
        if (playerCombatData == null && player != null)
        {
            playerCombatData = player.GetComponent<PlayerCombatData>();
        }

        return playerCombatData != null ? playerCombatData.BasicAttackRangeTiles : 1;
    }

    /// <summary>이번 턴 공격 순번을 반영한 기본 공격 MP 비용을 반환한다.</summary>
    private int GetPlayerBasicAttackCost()
    {
        int baseCost = playerCombatData != null ? playerCombatData.BasicAttackMPCost : 1;
        return Mathf.Max(0, baseCost) * (basicAttackCountThisTurn + 1);
    }

    /// <summary>현재 활성 Enemy가 점유한 MapInfo를 이동 금지 집합으로 갱신한다.</summary>
    private void RefreshOccupiedEnemyTiles()
    {
        occupiedEnemyTiles.Clear();
        EnemyTurnActor[] enemies = FindObjectsByType<EnemyTurnActor>(FindObjectsSortMode.None);
        foreach (EnemyTurnActor enemy in enemies)
        {
            if (enemy == null || !enemy.gameObject.activeInHierarchy)
            {
                continue;
            }

            MapInfo tile = FindClosestMapTile(enemy.transform.position);
            if (tile != null)
            {
                occupiedEnemyTiles.Add(tile);
            }
        }
    }

    /// <summary>
    /// 우클릭한 Enemy를 공격할 수 있는 후보 타일 중 이동 경로가 가장 짧은 타일을 선택한다.
    /// </summary>
    private void TryBeginBasicAttack(EnemyTurnActor enemy)
    {
        if (enemy == null || player == null || playerCombatData == null)
        {
            return;
        }

        MapInfo currentTile = FindClosestMapTile(player.transform.position);
        MapInfo enemyTile = FindClosestMapTile(enemy.transform.position);
        if (currentTile == null || enemyTile == null)
        {
            return;
        }

        int attackRange = GetPlayerAttackRange();
        List<MapInfo> bestPath = null;
        int bestAttackDistance = int.MaxValue;
        HashSet<MapInfo> origins = new HashSet<MapInfo>(reachableTiles) { currentTile };

        foreach (MapInfo origin in origins)
        {
            if (origin != currentTile && occupiedEnemyTiles.Contains(origin))
            {
                continue;
            }

            int attackDistance = GetTileDistance(origin, enemyTile, attackRange);
            if (attackDistance < 0)
            {
                continue;
            }

            if (!TryCalculatePath(currentTile, origin, out List<MapInfo> movementPath))
            {
                continue;
            }

            if (bestPath == null ||
                movementPath.Count < bestPath.Count ||
                (movementPath.Count == bestPath.Count && attackDistance < bestAttackDistance))
            {
                bestPath = movementPath;
                bestAttackDistance = attackDistance;
            }
        }

        if (bestPath == null)
        {
            Debug.Log("현재 이동 및 공격 범위에서 해당 적을 공격할 수 없습니다.", this);
            return;
        }

        CharacterMP playerMP = player.GetComponent<CharacterMP>();
        int actionCost = GetPlayerBasicAttackCost();
        int totalCost = bestPath.Count + actionCost;
        if (playerMP == null || !playerMP.CanSpend(totalCost))
        {
            Debug.Log($"기본 공격에 필요한 MP가 부족합니다. 필요 MP: {totalCost}", this);
            return;
        }

        pendingAction = new BattleActionRequest(
            "기본 공격",
            BattleActionType.BasicAttack,
            attackRange,
            actionCost,
            playerCombatData.BasicAttackPower);
        pendingEnemy = enemy;
        pendingMovementPath = new List<MapInfo>(bestPath);
        pendingOriginalTile = currentTile;
        pendingOriginalPosition = player.transform.position;

        StartCoroutine(MoveToPendingAttackPosition());
    }

    /// <summary>임시 이동에는 MP를 차감하지 않고 도착 후 공격 확인 UI를 표시한다.</summary>
    private IEnumerator MoveToPendingAttackPosition()
    {
        isMoving = true;
        yield return AnimatePlayerAlongPath(pendingMovementPath, pendingOriginalTile);
        isMoving = false;

        if (pendingEnemy == null || !pendingEnemy.gameObject.activeInHierarchy)
        {
            yield return CancelPendingActionAndReturn();
            yield break;
        }

        awaitingActionConfirm = true;

        if (confirmMoveButton != null)
            confirmMoveButton.interactable = true;
        if (quitMoveButton != null)
            quitMoveButton.interactable = true;

        SetActionConfirmText(
            $"{pendingEnemy.name}에게 {pendingAction.DisplayName}을 사용하시겠습니까? " +
            $"(필요 MP {pendingMovementPath.Count + pendingAction.MPCost})");

        SetMoveButtonGroupVisible(true);
    }

    /// <summary>두 타일 사이 거리가 최대 범위 이내면 칸 거리를, 아니면 -1을 반환한다.</summary>
    private int GetTileDistance(MapInfo start, MapInfo target, int maxDistance)
    {
        if (start == null || target == null)
            return -1;
        if (start == target)
            return 0;

        Queue<MapInfo> queue = new Queue<MapInfo>();
        Dictionary<MapInfo, int> distances = new Dictionary<MapInfo, int>();
        queue.Enqueue(start);
        distances[start] = 0;

        while (queue.Count > 0)
        {
            MapInfo current = queue.Dequeue();
            int distance = distances[current];
            if (distance >= maxDistance)
                continue;

            foreach (MapInfo neighbour in GetNeighbours(current))
            {
                if (neighbour == null || distances.ContainsKey(neighbour))
                    continue;

                int nextDistance = distance + 1;
                if (neighbour == target)
                    return nextDistance;

                distances[neighbour] = nextDistance;
                queue.Enqueue(neighbour);
            }
        }

        return -1;
    }

    /// <summary>이전 선택 색상을 복구한 뒤 새 목적지 강조, 화살표, 확정 UI를 표시한다.</summary>
    private void SelectMoveTile(MapInfo targetTile)
    {
        // 다른 타일을 다시 선택할 때 이전 선택 강조를 먼저 제거한다.
        ShowMoveRange();
        selectedMoveTile = targetTile;
        SetTileColor(targetTile, selectedTileColor, selectedColorBlend);
        ShowMoveArrow(targetTile);
        awaitingConfirm = true;
        SetActionConfirmText("선택한 타일로 이동하시겠습니까?");

        if (confirmMoveButton != null)
        {
            confirmMoveButton.interactable = true;
        }

        if (quitMoveButton != null)
        {
            quitMoveButton.interactable = true;
        }

        SetMoveButtonGroupVisible(true);
    }

    /// <summary>
    /// 목적지까지 최단 경로를 따라 이동하고 완료 후 경로 칸 수만큼 MP를 차감한다.
    /// 취소나 경로 실패에는 MP를 차감하지 않는다.
    /// </summary>
    private IEnumerator MovePlayerToTile(MapInfo targetTile)
    {
        if (player == null || targetTile == null || movementUsedThisTurn || !diceRolledThisTurn)
        {
            yield break;
        }

        MapInfo startTile = FindClosestMapTile(player.transform.position);
        if (!TryCalculatePath(startTile, targetTile, out List<MapInfo> path))
        {
            Debug.LogWarning("선택한 타일까지 이동 경로를 계산하지 못했습니다.", this);
            yield break;
        }

        CharacterMP playerMP = player.GetComponent<CharacterMP>();
        int moveCost = path.Count;
        if (playerMP != null && !playerMP.CanSpend(moveCost))
        {
            Debug.Log("현재 MP가 부족하여 선택한 타일까지 이동할 수 없습니다.", this);
            CancelMoveSelection();
            yield break;
        }

        isMoving = true;
        float playerHeightOffset = player.transform.position.y - startTile.transform.position.y;
        float timePerTile = Mathf.Max(0.01f, secondsPerTile / Mathf.Max(0.01f, moveSpeedMultiplier));

        foreach (MapInfo pathTile in path)
        {
            Vector3 stepStart = player.transform.position;
            Vector3 stepTarget = pathTile.transform.position + Vector3.up * playerHeightOffset;
            float elapsed = 0f;

            while (elapsed < timePerTile)
            {
                elapsed += Time.deltaTime;
                player.transform.position = Vector3.Lerp(
                    stepStart,
                    stepTarget,
                    Mathf.Clamp01(elapsed / timePerTile));
                yield return null;
            }

            player.transform.position = stepTarget;
        }

        if (playerMP != null && !playerMP.TrySpend(moveCost))
        {
            Debug.LogError("이동 완료 후 MP 차감에 실패했습니다.", this);
        }

        isMoving = false;
        movementUsedThisTurn = true;
        awaitingConfirm = false;
        selectedMoveTile = null;
        landedMoveTile = targetTile;

        ClearMoveRange();
        ClearMoveArrow();
        SetTileColor(targetTile, landedTileColor, landedColorBlend);

        if (landedHighlightRoutine != null)
        {
            StopCoroutine(landedHighlightRoutine);
        }
        landedHighlightRoutine = StartCoroutine(ClearLandedTileAfterDelay());

        if (BattleGameManager.Instance != null)
        {
            BattleGameManager.Instance.ResetDiceOnMove();
        }

        if (confirmMoveButton != null)
        {
            confirmMoveButton.interactable = false;
        }

        if (quitMoveButton != null)
        {
            quitMoveButton.interactable = false;
        }

        SetMoveButtonGroupVisible(false);
        SetActionConfirmText(string.Empty);
    }

    /// <summary>MP를 변경하지 않고 지정 경로를 따라 Player를 이동시킨다.</summary>
    private IEnumerator AnimatePlayerAlongPath(IReadOnlyList<MapInfo> path, MapInfo startTile)
    {
        if (player == null || path == null || startTile == null)
        {
            yield break;
        }

        float playerHeightOffset = player.transform.position.y - startTile.transform.position.y;
        float timePerTile = Mathf.Max(0.01f, secondsPerTile / Mathf.Max(0.01f, moveSpeedMultiplier));

        foreach (MapInfo pathTile in path)
        {
            Vector3 stepStart = player.transform.position;
            Vector3 stepTarget = pathTile.transform.position + Vector3.up * playerHeightOffset;
            float elapsed = 0f;

            while (elapsed < timePerTile)
            {
                elapsed += Time.deltaTime;
                player.transform.position = Vector3.Lerp(
                    stepStart,
                    stepTarget,
                    Mathf.Clamp01(elapsed / timePerTile));
                yield return null;
            }

            player.transform.position = stepTarget;
        }
    }

    /// <summary>임시 이동된 기본 공격을 확정 직전에 다시 검사하고 MP 차감 후 결과를 발행한다.</summary>
    private void ConfirmPendingAction()
    {
        if (!awaitingActionConfirm || pendingAction == null || pendingEnemy == null || player == null)
        {
            return;
        }

        MapInfo playerTile = FindClosestMapTile(player.transform.position);
        MapInfo enemyTile = FindClosestMapTile(pendingEnemy.transform.position);
        int attackDistance = GetTileDistance(playerTile, enemyTile, pendingAction.RangeTiles);
        CharacterMP playerMP = player.GetComponent<CharacterMP>();
        int actionCost = GetPlayerBasicAttackCost();
        int movementCost = pendingMovementPath.Count;
        int totalCost = movementCost + actionCost;

        if (!pendingEnemy.gameObject.activeInHierarchy ||
            attackDistance < 0 ||
            playerMP == null ||
            !playerMP.CanSpend(totalCost))
        {
            Debug.Log("공격 확정 직전 조건이 변경되어 기본 공격을 취소합니다.", this);
            StartCoroutine(CancelPendingActionAndReturn());
            return;
        }

        if (!playerMP.TrySpend(totalCost))
        {
            StartCoroutine(CancelPendingActionAndReturn());
            return;
        }

        BattleActionRequest confirmedRequest = new BattleActionRequest(
            pendingAction.DisplayName,
            pendingAction.ActionType,
            pendingAction.RangeTiles,
            actionCost,
            pendingAction.Power);
        BattleActionResult result = new BattleActionResult(
            confirmedRequest,
            player,
            pendingEnemy.gameObject,
            new List<MapInfo>(pendingMovementPath),
            movementCost,
            actionCost);

        if (movementCost > 0)
        {
            movementUsedThisTurn = true;
            BattleGameManager.Instance?.ResetDiceOnMove();
        }

        basicAttackCountThisTurn++;
        awaitingActionConfirm = false;
        SetMoveButtonGroupVisible(false);
        SetActionConfirmText(string.Empty);
        ClearPendingAction();

        ActionConfirmed?.Invoke(result);
        Debug.Log(
            $"기본 공격 확정: 이동 {movementCost}MP + 공격 {actionCost}MP, " +
            $"남은 MP {playerMP.CurrentMP}. 피해 적용은 아직 연결하지 않았습니다.",
            this);

        ShowMoveRange();
    }

    /// <summary>카드 사용 확인 단계를 열고 공용 확인·취소 버튼을 표시한다.</summary>
    public bool BeginCardUseConfirmation(
        PendingBattleCardUse cardUse,
        BattleCardDrawSystem cardDrawSystem)
    {
        if (cardUse == null || cardDrawSystem == null || player == null ||
            isMoving || awaitingConfirm || awaitingActionConfirm || awaitingCardConfirm || awaitingCardTarget)
        {
            return false;
        }

        if (BattleGameManager.Instance == null || !BattleGameManager.Instance.CanUsePlayerCards)
        {
            Debug.Log("주사위를 굴린 뒤 카드를 사용할 수 있습니다.", this);
            return false;
        }

        CharacterMP playerMP = player.GetComponent<CharacterMP>();
        int cardCost = cardUse.ActionRequest.MPCost;
        if (playerMP == null || !playerMP.CanSpend(cardCost))
        {
            Debug.Log($"카드 사용 불가: 행동력이 {cardCost} 필요합니다.", this);
            return false;
        }

        pendingCardUse = cardUse;
        pendingCardDrawSystem = cardDrawSystem;
        ClearMoveRange();

        BattleCardTargetType targetType = cardUse.CardData.targetType;
        if (targetType == BattleCardTargetType.None ||
            targetType == BattleCardTargetType.Self ||
            targetType == BattleCardTargetType.Ally)
        {
            pendingCardTarget = player;
            pendingCardTargetTile = FindClosestMapTile(player.transform.position);
            ShowCardConfirmation();
        }
        else
        {
            awaitingCardTarget = true;
            ShowCardRange();
            SetActionConfirmText($"{cardUse.ActionRequest.DisplayName}: 사거리 안의 대상을 우클릭하세요.");
        }

        return true;
    }

    private void SelectCardTarget(GameObject target, MapInfo targetTile)
    {
        pendingCardTarget = target;
        pendingCardTargetTile = targetTile;
        awaitingCardTarget = false;
        ShowCardConfirmation();
    }

    private void ShowCardConfirmation()
    {
        awaitingCardConfirm = true;
        if (confirmMoveButton != null)
        {
            confirmMoveButton.interactable = true;
        }

        if (quitMoveButton != null)
        {
            quitMoveButton.interactable = true;
        }

        SetActionConfirmText($"{pendingCardUse.ActionRequest.DisplayName} 카드를 사용하시겠습니까?");
        SetMoveButtonGroupVisible(true);
    }

    /// <summary>플레이어 현재 타일을 기준으로 카드의 사용 사거리를 표시한다.</summary>
    private void ShowCardRange()
    {
        RefreshMapTiles();
        RestoreAllTileColors();
        cardRangeTiles.Clear();

        MapInfo startTile = FindClosestMapTile(player.transform.position);
        if (startTile == null)
        {
            Debug.LogWarning("카드 사거리 계산을 위한 플레이어 타일을 찾지 못했습니다.", this);
            CancelPendingCardUse();
            return;
        }

        Queue<MapInfo> queue = new Queue<MapInfo>();
        Dictionary<MapInfo, int> distances = new Dictionary<MapInfo, int>();
        queue.Enqueue(startTile);
        distances[startTile] = 0;

        while (queue.Count > 0)
        {
            MapInfo current = queue.Dequeue();
            int distance = distances[current];
            if (distance > 0)
            {
                cardRangeTiles.Add(current);
                SetTileColor(current, cardRangeTileColor);
            }

            if (distance >= pendingCardUse.ActionRequest.RangeTiles)
            {
                continue;
            }

            foreach (MapInfo neighbour in GetNeighbours(current))
            {
                if (neighbour == null || distances.ContainsKey(neighbour))
                {
                    continue;
                }

                distances[neighbour] = distance + 1;
                queue.Enqueue(neighbour);
            }
        }

        SetRangeVisible(true);
    }

    /// <summary>카드 비용을 다시 검사하고 행동력을 차감한 뒤 카드를 버림 더미로 이동한다.</summary>
    private void ConfirmPendingCardUse()
    {
        if (!awaitingCardConfirm || pendingCardUse == null || pendingCardDrawSystem == null || player == null)
        {
            return;
        }

        CharacterMP playerMP = player.GetComponent<CharacterMP>();
        int cardCost = pendingCardUse.ActionRequest.MPCost;
        BattleCardTargetType targetType = pendingCardUse.CardData.targetType;
        bool requiresExternalTarget = targetType == BattleCardTargetType.Enemy ||
                                      targetType == BattleCardTargetType.Character ||
                                      targetType == BattleCardTargetType.Tile;
        if (requiresExternalTarget &&
            (pendingCardTarget == null || pendingCardTargetTile == null ||
             !pendingCardTarget.activeInHierarchy || !cardRangeTiles.Contains(pendingCardTargetTile)))
        {
            Debug.Log("카드 대상이 사라졌거나 사거리 밖으로 이동하여 대상 선택 단계로 돌아갑니다.", this);
            awaitingCardConfirm = false;
            awaitingCardTarget = true;
            pendingCardTarget = null;
            pendingCardTargetTile = null;
            SetMoveButtonGroupVisible(false);
            ShowCardRange();
            return;
        }

        if (playerMP == null || !playerMP.CanSpend(cardCost))
        {
            Debug.Log($"카드 사용 취소: 행동력이 {cardCost} 필요합니다.", this);
            CancelPendingCardUse();
            return;
        }

        if (!pendingCardDrawSystem.ConfirmCardUse(pendingCardUse))
        {
            Debug.LogError("카드 확정 실패: 손패에서 선택한 카드를 찾을 수 없습니다.", this);
            CancelPendingCardUse();
            return;
        }

        playerMP.TrySpend(cardCost);

        BattleActionResult result = new BattleActionResult(
            pendingCardUse.ActionRequest,
            player,
            pendingCardTarget,
            new List<MapInfo>(),
            0,
            cardCost);

        Debug.Log(
            $"카드 사용 확정: {pendingCardUse.ActionRequest.DisplayName}, " +
            $"소모 {cardCost}MP, 남은 MP {playerMP.CurrentMP}.",
            this);

        // 체력 시스템 연결 후 이 지점에서 pendingCardUse.CardData.damage를 대상에게 적용한다.
        ActionConfirmed?.Invoke(result);

        BattleCardPanelToggle cardPanelToggle = FindFirstObjectByType<BattleCardPanelToggle>();
        cardPanelToggle?.Hide();

        ClearPendingCardUse();
        RestoreAllTileColors();
        SetRangeVisible(false);
        SetMoveButtonGroupVisible(false);
        SetActionConfirmText(string.Empty);
    }

    /// <summary>카드 사용 확인을 취소하고 손패와 행동력을 유지한다.</summary>
    private void CancelPendingCardUse()
    {
        ClearPendingCardUse();
        RestoreAllTileColors();
        SetRangeVisible(false);
        SetMoveButtonGroupVisible(false);
        SetActionConfirmText(string.Empty);
    }

    private void ClearPendingCardUse()
    {
        awaitingCardConfirm = false;
        awaitingCardTarget = false;
        pendingCardUse = null;
        pendingCardDrawSystem = null;
        pendingCardTarget = null;
        pendingCardTargetTile = null;
        cardRangeTiles.Clear();
    }

    /// <summary>임시 공격 이동을 원래 위치로 되돌리고 MP 소비 없이 범위 선택 단계로 복귀한다.</summary>
    private IEnumerator CancelPendingActionAndReturn()
    {
        awaitingActionConfirm = false;
        SetMoveButtonGroupVisible(false);
        SetActionConfirmText(string.Empty);
        isMoving = true;

        if (player != null)
        {
            Vector3 startPosition = player.transform.position;
            float duration = Mathf.Max(
                0.01f,
                pendingMovementPath.Count * secondsPerTile / Mathf.Max(0.01f, moveSpeedMultiplier));
            float elapsed = 0f;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                player.transform.position = Vector3.Lerp(
                    startPosition,
                    pendingOriginalPosition,
                    Mathf.Clamp01(elapsed / duration));
                yield return null;
            }

            player.transform.position = pendingOriginalPosition;
        }

        isMoving = false;
        ClearPendingAction();
        ShowMoveRange();
    }

    /// <summary>임시 행동 참조만 초기화하며 Player 위치나 MP는 변경하지 않는다.</summary>
    private void ClearPendingAction()
    {
        pendingAction = null;
        pendingEnemy = null;
        pendingMovementPath.Clear();
        pendingOriginalTile = null;
        pendingOriginalPosition = Vector3.zero;
    }

    /// <summary>이동 또는 공격 확정 단계의 안내 문구를 전투 확인 텍스트에 표시한다.</summary>
    private void SetActionConfirmText(string message)
    {
        if (actionConfirmText != null)
        {
            actionConfirmText.text = message;
        }
    }

    /// <summary>Player 현재 타일에서 목적지까지 이동 가능한 BFS 최단 경로를 계산한다.</summary>
    private bool TryCalculatePath(MapInfo startTile, MapInfo targetTile, out List<MapInfo> path)
    {
        path = new List<MapInfo>();

        if (startTile == null || targetTile == null)
        {
            return false;
        }

        if (startTile == targetTile)
        {
            return true;
        }

        Queue<MapInfo> queue = new Queue<MapInfo>();
        Dictionary<MapInfo, MapInfo> previousTiles = new Dictionary<MapInfo, MapInfo>();
        queue.Enqueue(startTile);
        previousTiles[startTile] = null;

        while (queue.Count > 0)
        {
            MapInfo current = queue.Dequeue();

            foreach (MapInfo neighbour in GetNeighbours(current))
            {
                if (neighbour == null ||
                    previousTiles.ContainsKey(neighbour) ||
                    !IsWalkable(neighbour) ||
                    occupiedEnemyTiles.Contains(neighbour))
                {
                    continue;
                }

                previousTiles[neighbour] = current;

                if (neighbour == targetTile)
                {
                    MapInfo pathTile = targetTile;
                    while (pathTile != startTile)
                    {
                        path.Add(pathTile);
                        pathTile = previousTiles[pathTile];
                    }

                    path.Reverse();
                    return true;
                }

                queue.Enqueue(neighbour);
            }
        }

        return false;
    }

    /// <summary>
    /// 확정 대기 단계에서는 이동 범위 단계로 돌아가고, 범위 단계에서는 표시를 완전히 닫는다.
    /// </summary>
    public void CancelMoveSelection()
    {
        if (awaitingCardConfirm)
        {
            BattleCardTargetType targetType = pendingCardUse.CardData.targetType;
            if (targetType == BattleCardTargetType.None ||
                targetType == BattleCardTargetType.Self ||
                targetType == BattleCardTargetType.Ally)
            {
                CancelPendingCardUse();
                return;
            }

            awaitingCardConfirm = false;
            awaitingCardTarget = true;
            pendingCardTarget = null;
            pendingCardTargetTile = null;
            SetMoveButtonGroupVisible(false);
            ShowCardRange();
            SetActionConfirmText($"{pendingCardUse.ActionRequest.DisplayName}: 사거리 안의 대상을 우클릭하세요.");
            return;
        }

        if (awaitingCardTarget)
        {
            CancelPendingCardUse();
            return;
        }

        if (awaitingActionConfirm)
        {
            StartCoroutine(CancelPendingActionAndReturn());
            return;
        }

        bool returnToMoveRange = awaitingConfirm;
        awaitingConfirm = false;
        selectedMoveTile = null;
        ClearMoveArrow();

        if (confirmMoveButton != null)
        {
            confirmMoveButton.interactable = false;
        }

        if (quitMoveButton != null)
        {
            quitMoveButton.interactable = false;
        }

        SetMoveButtonGroupVisible(false);
        SetActionConfirmText(string.Empty);

        if (returnToMoveRange)
        {
            ShowMoveRange();
        }
        else
        {
            ClearMoveRange();
        }
    }

    /// <summary>도착 강조를 지정 시간 뒤 원래 타일 색상으로 복구한다.</summary>
    private IEnumerator ClearLandedTileAfterDelay()
    {
        yield return new WaitForSeconds(landedHighlightDuration);

        if (landedMoveTile != null)
        {
            RestoreTileColor(landedMoveTile);
        }

        landedMoveTile = null;
        landedHighlightRoutine = null;
    }

    /// <summary>참조 Camera가 없거나 비활성화됐으면 현재 Main Camera를 다시 찾는다.</summary>
    private void RefreshCamera()
    {
        if (mainCamera == null || !mainCamera.isActiveAndEnabled)
        {
            mainCamera = Camera.main;
        }
    }

    /// <summary>비활성 화면 요소를 포함해 이름이 일치하는 버튼을 찾는다.</summary>
    private Button FindButtonByName(string buttonName)
    {
        Button[] buttons = FindObjectsByType<Button>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (Button button in buttons)
        {
            if (button != null && button.name == buttonName)
            {
                return button;
            }
        }

        return null;
    }

    /// <summary>비활성 오브젝트를 포함해 이름이 일치하는 오브젝트를 찾는다.</summary>
    private GameObject FindGameObjectByName(string objectName)
    {
        Transform[] transforms = FindObjectsByType<Transform>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (Transform targetTransform in transforms)
        {
            if (targetTransform != null && targetTransform.name == objectName)
            {
                return targetTransform.gameObject;
            }
        }

        return null;
    }

    /// <summary>비활성 UI까지 포함해 이름으로 TMP Text를 찾는다.</summary>
    private TMP_Text FindTextByName(string textName)
    {
        TMP_Text[] texts = FindObjectsByType<TMP_Text>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (TMP_Text text in texts)
        {
            if (text != null && text.name == textName)
            {
                return text;
            }
        }

        return null;
    }

    /// <summary>확정/취소 부모를 우선 토글하고, 참조가 없으면 개별 버튼을 토글한다.</summary>
    private void SetMoveButtonGroupVisible(bool visible)
    {
        if (moveButtonGroup != null)
        {
            moveButtonGroup.SetActive(visible);
            return;
        }

        // 부모 참조가 없어도 기존 개별 버튼 연결은 유지한다.
        if (confirmMoveButton != null)
        {
            confirmMoveButton.gameObject.SetActive(visible);
        }

        if (quitMoveButton != null)
        {
            quitMoveButton.gameObject.SetActive(visible);
        }
    }

    /// <summary>현재 생성된 MapInfo 목록을 다시 수집하고 원본 Material 색상을 보관한다.</summary>
    private void RefreshMapTiles()
    {
        cachedMapTiles.Clear();
        cachedMapTiles.AddRange(FindObjectsByType<MapInfo>(FindObjectsSortMode.None));
        CacheOriginalColors();
    }

    /// <summary>Ray 표시 종료 시 되돌릴 수 있도록 Renderer별 최초 색상을 한 번만 저장한다.</summary>
    private void CacheOriginalColors()
    {
        foreach (MapInfo tile in cachedMapTiles)
        {
            if (tile == null)
            {
                continue;
            }

            foreach (Renderer renderer in tile.GetComponentsInChildren<Renderer>(true))
            {
                if (renderer != null && !originalColors.ContainsKey(renderer) && renderer.material.HasProperty("_Color"))
                {
                    originalColors[renderer] = renderer.material.color;
                }
            }
        }
    }

    /// <summary>일반 범위 혼합 강도로 타일 색상을 표시한다.</summary>
    private void SetTileColor(MapInfo tile, Color color)
    {
        SetTileColor(tile, color, rangeColorBlend);
    }

    /// <summary>원본색과 표시색을 지정 강도로 혼합해 원본 맵 가시성을 유지한다.</summary>
    private void SetTileColor(MapInfo tile, Color color, float blendStrength)
    {
        if (tile == null)
        {
            return;
        }

        foreach (Renderer renderer in tile.GetComponentsInChildren<Renderer>(true))
        {
            if (renderer != null && renderer.material.HasProperty("_Color"))
            {
                Color baseColor = originalColors.TryGetValue(renderer, out Color originalColor)
                    ? originalColor
                    : renderer.material.color;
                renderer.material.color = Color.Lerp(baseColor, color, Mathf.Clamp01(blendStrength));
            }
        }
    }

    /// <summary>특정 타일 Renderer를 캐시된 원본색으로 복구한다.</summary>
    private void RestoreTileColor(MapInfo tile)
    {
        if (tile == null)
        {
            return;
        }

        foreach (Renderer renderer in tile.GetComponentsInChildren<Renderer>(true))
        {
            if (renderer != null && originalColors.TryGetValue(renderer, out Color color))
            {
                renderer.material.color = color;
            }
        }
    }

    /// <summary>RayTest가 변경한 모든 타일 Renderer 색상을 원본으로 복구한다.</summary>
    private void RestoreAllTileColors()
    {
        foreach (KeyValuePair<Renderer, Color> entry in originalColors)
        {
            if (entry.Key != null && entry.Key.material.HasProperty("_Color"))
            {
                entry.Key.material.color = entry.Value;
            }
        }
    }

    /// <summary>타일 색상, 도달 가능 집합, 전역 범위 표시 상태를 초기화한다.</summary>
    private void ClearMoveRange()
    {
        RestoreAllTileColors();
        reachableTiles.Clear();
        attackableTiles.Clear();
        reachableDistances.Clear();
        SetRangeVisible(false);
    }

    /// <summary>AI 경로 Debug 표시와 충돌하지 않도록 범위 가시성 변경 이벤트를 보낸다.</summary>
    private void SetRangeVisible(bool visible)
    {
        rangeVisible = visible;

        if (IsMoveRangeVisible == visible)
        {
            return;
        }

        IsMoveRangeVisible = visible;
        MoveRangeVisibilityChanged?.Invoke(visible);
    }

    /// <summary>타일이 하나 이상의 Enemy 감지 거리 안에 있는지 검사한다.</summary>
    private bool IsInAnyEnemyDetectRange(Vector3 tilePosition)
    {
        EnemyDetector[] enemies = FindObjectsByType<EnemyDetector>(FindObjectsSortMode.None);
        foreach (EnemyDetector enemy in enemies)
        {
            if (enemy != null && Vector3.Distance(enemy.transform.position, tilePosition) <= enemy.DetectRange)
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>목적지 위에 화살표 프리팹을 생성 또는 재사용해 표시한다.</summary>
    private void ShowMoveArrow(MapInfo targetTile)
    {
        if (targetTile == null || moveArrowPrefab == null)
        {
            return;
        }

        if (moveArrowInstance == null)
        {
            moveArrowInstance = Instantiate(moveArrowPrefab);
            moveArrowInstance.name = "MoveArrowPreview";
        }

        moveArrowInstance.transform.position = targetTile.transform.position + arrowOffset;
        moveArrowInstance.transform.rotation = Quaternion.identity;
        moveArrowInstance.SetActive(true);
    }

    /// <summary>화살표 인스턴스를 파괴하지 않고 비활성화해 재사용한다.</summary>
    private void ClearMoveArrow()
    {
        if (moveArrowInstance != null)
        {
            moveArrowInstance.SetActive(false);
        }
    }
}
