using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChooseCharactorIndex : MonoBehaviour
{
    [SerializeField]
    public int charactorIndex;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
