using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnPlayer : MonoBehaviour
{
    [SerializeField]
    GameObject[] playerPrefab;
    [SerializeField]
    GameObject playerBody;
    [SerializeField]
    MapGenerator mapGenerator;

    [SerializeField]
    GameObject charactorStatus;

    private GameObject player;



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void PlayerPosInit(int charactorIndex)
    {
        mapGenerator.StartGenerator();
        player = Instantiate(playerPrefab[charactorIndex], playerBody.transform);
        StartCoroutine(waitUnitMApGen());
    }

    public void PlayerInfoInit()
    {

    }

    public IEnumerator waitUnitMApGen()
    {

        while (!mapGenerator.IsGenerateEnd())
        {
            yield return null;
        }
        //���̵� �ƿ� �ڵ� �߰�
        PlayerInfoInit();

        //ī�޶� �̵� �ڵ�
        Camera.main.GetComponent<CameraChase>().InitTarget(player);

    }
}
