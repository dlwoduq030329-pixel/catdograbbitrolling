using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PlayerChoose : MonoBehaviour
{
    [Header("캐릭터 선택")]
    [SerializeField]
    private Animator[] charactorAnimator;
    [SerializeField]
    private GameObject setBtn;

    [Header("카메라")]
    [SerializeField]
    private Vector3 cameraPositionOffset;

    [Header("선택 화면 UI")]
    [SerializeField]
    GameObject[] UI;
    [SerializeField]
    GameObject statusUI;

    int charactorIndex;
    bool Choose = false;
    private void Awake()
    {
        SetSelectionUIActive(false);
        if (setBtn != null)
        {
            setBtn.SetActive(false);
        }
    }

    // Update is called once per frame
    void Update()
    {
        ShootRayForCharactor();
    }


    void ShootRayForCharactor()
    {
        if (Choose) return;
        if (EventSystem.current.IsPointerOverGameObject()) // 방어 코드용으로
            return;
        if (Input.GetMouseButtonDown(0))
        {
            // 마우스 위치에서 카메라 기준 레이 생성
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            // 레이가 충돌하는지 확인
            if (Physics.Raycast(ray, out hit, Mathf.Infinity,LayerMask.GetMask("Choose")))
            {
                foreach(var anim in charactorAnimator)
                {
                    if (anim.GetCurrentAnimatorStateInfo(0).IsName("Sit_Floor_Down") == true) continue;

                    anim.Play("Sit_Floor_Down");
                }
                Debug.Log(hit.collider.gameObject.name);
                //hit.collider.GetComponent<Renderer>().material.color = Color.red;

                ChooseCharactorIndex selectedCharacter = hit.collider.GetComponent<ChooseCharactorIndex>();
                if (selectedCharacter == null)
                {
                    return;
                }

                charactorIndex = selectedCharacter.charactorIndex;
                if (charactorIndex < 0 || charactorIndex >= charactorAnimator.Length)
                {
                    return;
                }

                // 애니메이션 상태와 관계없이 선택 UI를 먼저 표시한다.
                SetSelectionUIActive(true);
                if (setBtn != null)
                {
                    setBtn.SetActive(true);
                }

                if (!charactorAnimator[charactorIndex].GetCurrentAnimatorStateInfo(0).IsName("Skeletons_Awaken_Standing"))
                {
                    charactorAnimator[charactorIndex].Play("Skeletons_Awaken_Standing");
                }
            }
            else
            {
                if (setBtn != null)
                {
                    setBtn.SetActive(false);
                }
                SetSelectionUIActive(false);
                foreach (var anim in charactorAnimator)
                {
                    if (anim.GetCurrentAnimatorStateInfo(0).IsName("Sit_Floor_Down") == true) continue;

                    anim.Play("Sit_Floor_Down");
                }
                charactorIndex = -1;
            }

        }
    }

    public void SetCharactor()
    {
        //Camera.main.orthographic = false;
        //Camera.main.orthographicSize = 0.5f;
        Choose = true;
        StartCoroutine(cameraClose());
        SetSelectionUIActive(false);
    }

    public IEnumerator cameraClose()
    {

        for(int i =0;i<charactorAnimator.Length;i++)
        {
            if(i==charactorIndex)
            {
                charactorAnimator[i].Play("Waving");
            }else
            {
                charactorAnimator[i].Play("Cheering");

            }
        }

        yield return new WaitForSeconds(1f);
        float duration = 1f;
        float time = 0f;

        Vector3 startPos = Camera.main.transform.position;
        Vector3 targetPos = charactorAnimator[charactorIndex].transform.position + cameraPositionOffset;

        while (time < duration)
        {
            time += Time.deltaTime;

            Camera.main.transform.position =
                Vector3.Lerp(startPos, targetPos, time / duration);
            Camera.main.orthographicSize = Mathf.Lerp(2.32f, 0.8f, time / duration);


            yield return null;
        }

        // 마지막 위치 보정
        Camera.main.transform.position = targetPos;
        statusUI.SetActive(true);
        statusUI.GetComponent<StatusUI>().TextSet(charactorIndex);
    }

    public void BackChoose()
    {
        Choose = false;
        statusUI.GetComponent<StatusUI>().playerIndex = -1;
        StartCoroutine(cameraFar());
        
    }

    public IEnumerator cameraFar()
    {
        for (int i = 0; i < charactorAnimator.Length; i++)
        {
             charactorAnimator[i].Play("Sit_Floor_Down");
        }
        statusUI.SetActive(false);

        yield return new WaitForSeconds(1f);
        float duration = 1f;
        float time = 0f;

        Vector3 startPos = Camera.main.transform.position;

        Vector3 targetPos = new Vector3(100, 101.61f, 103.95f);

        while (time < duration)
        {
            time += Time.deltaTime;

            Camera.main.transform.position =
                Vector3.Lerp(startPos, targetPos, time / duration);
            Camera.main.orthographicSize = Mathf.Lerp(0.8f,2.32f, time / duration);


            yield return null;
        }

        // 마지막 위치 보정
        Camera.main.transform.position = targetPos;
        SetSelectionUIActive(true);
        if (setBtn != null)
        {
            setBtn.SetActive(false);
        }
        //statusUI.GetComponent<StatusUI>().TextSet(charactorIndex);

    }

    /// <summary>
    /// 캐릭터 선택 단계에서 사용하는 UI를 일괄 표시하거나 숨긴다.
    /// </summary>
    private void SetSelectionUIActive(bool active)
    {
        if (UI == null)
        {
            return;
        }

        foreach (GameObject selectionUI in UI)
        {
            if (selectionUI != null)
            {
                selectionUI.SetActive(active);
            }
        }
    }
}
