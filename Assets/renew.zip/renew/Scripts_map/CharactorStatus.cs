using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharactorStatus : MonoBehaviour
{
    int str_st;
    int dex_st;
    int int_st;
    int wis_st;
    int car_st;
    int vit_st;

    float attackRange;

    int playerHp;


    public void InitStatus()
    {

    }
}
