using UnityEngine;

public class CameraChase : MonoBehaviour
{
    [Header("카메라 추적 설정")]
    [InspectorName("기본 위치 보정")]
    [SerializeField] private Vector3 offset;
    [InspectorName("추적 속도")]
    [SerializeField] private float chaseOffset;

    [Header("카메라 줌 제한")]
    [InspectorName("최소 높이")]
    [SerializeField] private float minZoomHeight = 5f;
    [InspectorName("최대 높이")]
    [SerializeField] private float maxZoomHeight = 40f;

    private GameObject targetPlayer;
    private Vector3 manualPanOffset;
    private bool isTargeted;
    private bool hasMapBounds;
    private float minMapX;
    private float maxMapX;
    private float minMapZ;
    private float maxMapZ;

    public float CurrentZoomHeight => offset.y;

    private void LateUpdate()
    {
        if (!isTargeted || targetPlayer == null)
        {
            return;
        }

        ClampPanToMap();
        Vector3 desiredPosition = targetPlayer.transform.position + offset + manualPanOffset;
        transform.position = Vector3.Lerp(
            transform.position,
            desiredPosition,
            chaseOffset * Time.deltaTime);
    }

    public void InitTarget(GameObject targetTemp)
    {
        targetPlayer = targetTemp;
        isTargeted = targetPlayer != null;
        manualPanOffset = Vector3.zero;
        RefreshMapBounds();

        Camera targetCamera = GetComponent<Camera>();
        if (targetCamera != null)
        {
            targetCamera.orthographic = false;
        }

        transform.rotation = Quaternion.Euler(90f, 0f, 0f);
    }

    public void AddPan(Vector3 worldDelta)
    {
        manualPanOffset += new Vector3(worldDelta.x, 0f, worldDelta.z);
        ClampPanToMap();
    }

    public void AddZoom(float heightDelta)
    {
        offset.y = Mathf.Clamp(offset.y + heightDelta, minZoomHeight, maxZoomHeight);
    }

    public void ResetManualView()
    {
        manualPanOffset = Vector3.zero;
        ClampPanToMap();
    }

    private void RefreshMapBounds()
    {
        MapInfo[] tiles = FindObjectsByType<MapInfo>(FindObjectsSortMode.None);
        if (tiles.Length == 0)
        {
            hasMapBounds = false;
            return;
        }

        minMapX = maxMapX = tiles[0].transform.position.x;
        minMapZ = maxMapZ = tiles[0].transform.position.z;

        foreach (MapInfo tile in tiles)
        {
            if (tile == null)
            {
                continue;
            }

            Vector3 position = tile.transform.position;
            minMapX = Mathf.Min(minMapX, position.x);
            maxMapX = Mathf.Max(maxMapX, position.x);
            minMapZ = Mathf.Min(minMapZ, position.z);
            maxMapZ = Mathf.Max(maxMapZ, position.z);
        }

        hasMapBounds = true;
    }

    private void ClampPanToMap()
    {
        if (!hasMapBounds || targetPlayer == null)
        {
            return;
        }

        Vector3 playerPosition = targetPlayer.transform.position;
        float focusX = Mathf.Clamp(playerPosition.x + manualPanOffset.x, minMapX, maxMapX);
        float focusZ = Mathf.Clamp(playerPosition.z + manualPanOffset.z, minMapZ, maxMapZ);
        manualPanOffset.x = focusX - playerPosition.x;
        manualPanOffset.z = focusZ - playerPosition.z;
    }
}
